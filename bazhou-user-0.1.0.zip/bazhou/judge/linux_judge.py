#!/usr/bin/env python3
"""L10（platform=linux）章节的正式判题入口：经 ExecutionBackend 在 Linux 上判题。

设计目标（最小兼容扩展，不动 engine 主流程）：
  · 复用 engine 的 Verdict / AC / WA / RE / SE 常量与 compare_output 比对规则
    ——判定语义与 Windows 路径完全一致；
  · 执行层换成本项目的 ExecutionBackend（Linux 上 LinuxNativeBackend、
    Windows 上 WSL2Backend）——同一入口可被健康检查、章节验证脚本与
    桌面端（未来接线）共同使用；
  · 支持 output 题的多组测试（tests 数组）：**每组一个独立私有工作目录**
    （backend 每次 execute 都新建 mkdtemp），支持 stdin 与 prefiles（预置文件），
    **全部必需场景通过才判 AC**；逐组记录实际输出/退出码/判定结果。

用法：
    import linux_judge
    v = linux_judge.judge_exercise(ex, answer="", backend=None)
    v.verdict  # AC / WA / RE / SE，message 内含逐组记录

安全边界：与 backend 相同——只面向用户可信练习代码，不是安全沙箱。
"""
from __future__ import annotations

import platform as _platform

import engine
from backend import (
    CompileRequest,
    ExecutionBackend,
    LinuxNativeBackend,
    RunRequest,
    WSL2Backend,
)

AC, WA, RE, SE = engine.AC, engine.WA, engine.RE, engine.SE

DEFAULT_COMPILE_FLAGS = ["-std=c++20"]
DEFAULT_TIME_LIMIT_S = 15


def pick_backend() -> ExecutionBackend:
    """当前平台默认的 Linux 后端：Linux 上本机，Windows 上经 WSL2。"""
    if _platform.system() == "Linux":
        return LinuxNativeBackend()
    return WSL2Backend()


def _run_once(backend: ExecutionBackend, code: str, *, stdin: str = "",
              prefiles: dict | None = None):
    """编译并运行一次；返回 (ExecutionResult | None, error_message | None)。"""
    r = backend.execute(
        CompileRequest(source_files={"main.cpp": code}, compile_flags=DEFAULT_COMPILE_FLAGS),
        RunRequest(time_limit_s=DEFAULT_TIME_LIMIT_S, stdin=stdin, prefiles=prefiles or {}),
    )
    if not r.compile.success:
        return None, f"编译失败：{(r.compile.diagnostics or '').strip()[:400]}"
    if r.run is None:
        return None, "执行器未返回运行结果"
    return r, None


def judge_exercise(ex: dict, *, answer: str = "", backend: ExecutionBackend | None = None):
    """判一道 Linux 平台章节的题（output / predict_output / multiple_choice）。

    · output：有 tests 数组则逐组判定（每组独立工作目录，全过才 AC），
      否则单组（stdin + expected）。
    · predict_output：真实运行示例代码 → 核验题目内容（真实输出 == expected）
      → 再用 compare_output 判定用户答案；空答案判 WA。
    · multiple_choice：不涉及编译，直接交给 engine（纯逻辑）。
    """
    mode = engine.normalize_mode(ex.get("mode", "") or "")
    ex_id = ex.get("id", "?")

    if mode == "multiple_choice":
        # 纯逻辑判定，本地实现，避免触碰 engine 的执行路径（其依赖 Windows 沙箱）
        idx = engine.correct_choice_index(ex.get("choices") or [])
        if idx is None:
            return engine.Verdict(SE, "选择题没有 correct: true 的选项")
        if not (answer or "").strip():
            return engine.Verdict(WA, "还没有选择答案。")
        try:
            chosen = int(str(answer).strip())
        except ValueError:
            return engine.Verdict(WA, "答案格式不对（应提交选项下标）。")
        if chosen == idx:
            return engine.Verdict(AC, "选择正确 ✅")
        return engine.Verdict(WA, f"选择不对（正确答案是第 {idx + 1} 项）。")

    backend = backend or pick_backend()
    st = backend.state()
    if st.value != "AVAILABLE":
        return engine.Verdict(SE, f"Linux 判题后端不可用（{backend.backend_id()}={st.value}）")

    code = ex.get("code", "") or ""
    expected = ex.get("expected", "") or ""
    float_tol = ex.get("floatTol")

    # ── predict_output ────────────────────────────────────────────────
    if mode == "predict_output":
        r, err = _run_once(backend, code, stdin=ex.get("stdin", "") or "")
        if err:
            return engine.Verdict(SE, err)
        real = r.run.stdout
        ok, hint = engine.compare_output(real, expected, None)
        if not ok:
            # 题目内容自检：示例真实输出必须等于 expected
            return engine.Verdict(
                SE,
                f"题目内容错误：示例代码真实输出与 expected 不一致（{hint}）",
                stdout=real,
            )
        if not (answer or "").strip():
            return engine.Verdict(WA, "还没有填写预测答案。", actual_output=real)
        ok2, hint2 = engine.compare_output(answer, expected, float_tol)
        if ok2:
            return engine.Verdict(AC, "预测正确 ✅", actual_output=real)
        return engine.Verdict(WA, f"预测不对。{hint2}", actual_output=real)

    if mode != "output":
        return engine.Verdict(SE, f"linux_judge 暂不支持 mode={mode!r}（题 {ex_id}）")

    # ── output：多组测试优先 ──────────────────────────────────────────
    tests = ex.get("tests") or []
    if tests:
        total = len(tests)
        report: list[str] = []
        for i, t in enumerate(tests, 1):
            name = (t.get("name") or f"第 {i} 组") if isinstance(t, dict) else f"第 {i} 组"
            tin = (t.get("stdin") or "") if isinstance(t, dict) else ""
            texp = (t.get("expected") or "") if isinstance(t, dict) else ""
            pre = (t.get("prefiles") or {}) if isinstance(t, dict) else {}
            r, err = _run_once(backend, code, stdin=tin, prefiles=pre)
            if err:
                report.append(f"{name}: 编译/执行环境错误 → SE")
                return engine.Verdict(SE, f"{err}\n" + "\n".join(report))
            if r.run.exit_code is None and r.run.signal is not None:
                report.append(f"{name}: 被信号终止 signal={r.run.signal} → RE")
                return engine.Verdict(
                    RE, f"测试「{name}」程序异常终止（signal={r.run.signal}）\n" + "\n".join(report),
                    stdout=r.run.stdout, stderr=r.run.stderr)
            if r.run.timed_out:
                report.append(f"{name}: 超时 → RE")
                return engine.Verdict(RE, f"测试「{name}」运行超时\n" + "\n".join(report))
            if r.run.exit_code != 0:
                report.append(f"{name}: 退出码 {r.run.exit_code} → RE")
                return engine.Verdict(
                    RE, f"测试「{name}」程序异常退出（退出码 {r.run.exit_code}）\n" + "\n".join(report),
                    stdout=r.run.stdout, stderr=r.run.stderr)
            ok, hint = engine.compare_output(r.run.stdout, texp, None)
            report.append(
                f"{name}: rc=0 out={r.run.stdout.strip()!r} expected={texp.strip()!r} "
                f"→ {'PASS' if ok else 'FAIL'}")
            if not ok:
                return engine.Verdict(
                    WA,
                    f"测试「{name}」未通过（第 {i}/{total} 组）：{hint}\n" + "\n".join(report),
                    stdout=r.run.stdout, stderr=r.run.stderr)
        return engine.Verdict(
            AC, f"全部 {total} 组测试通过 ✅（含边界与反例场景）\n" + "\n".join(report),
            stdout=r.run.stdout)

    # ── output：单组 ─────────────────────────────────────────────────
    r, err = _run_once(backend, code, stdin=ex.get("stdin", "") or "")
    if err:
        return engine.Verdict(SE, err)
    if r.run.exit_code != 0 and not r.run.timed_out:
        return engine.Verdict(RE, f"程序异常退出（退出码 {r.run.exit_code}）",
                              stdout=r.run.stdout, stderr=r.run.stderr)
    if r.run.timed_out:
        return engine.Verdict(RE, "运行超时")
    ok, hint = engine.compare_output(r.run.stdout, expected, float_tol)
    if ok:
        return engine.Verdict(AC, "通过 ✅", stdout=r.run.stdout)
    return engine.Verdict(WA, hint, stdout=r.run.stdout, stderr=r.run.stderr)
