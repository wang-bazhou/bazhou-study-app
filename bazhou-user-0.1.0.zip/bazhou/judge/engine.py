"""判题引擎：三种题型 mode 的判定逻辑。

===============================================================================
和上一轮（Linux 沙箱）的关系
===============================================================================
判定逻辑**原样复用**上一轮已验证的成果，三种 mode 的行为保持不变：

    mode           判定方式                             适用知识点
    --------------+------------------------------------+---------------------------
    output        stdout 比对（支持浮点容差）           输出预测、算法、语法
    compile_fail  期望编译失败（static_assert 类题）     类型推导、SFINAE、traits
    asan          ASan+UBSan 无报警（可叠加输出校验）     UB、越界、悬垂指针、找 bug

唯一改动的是"怎么限制进程"这一层——换成了 sandbox_win.py 的 Job Object。
判定码集合不变：AC / WA / CE / RE / TLE / MLE / OLE，另加 SE（沙箱自身出错，
不是用户代码的问题）。

===============================================================================
设计原则 1 的落地（交接文档第六条）
===============================================================================
UB 类知识点**不能**用"运行结果比对"判题。所以 asan 模式的判据是进程退出码
和 sanitizer 报告，而不是输出内容——目标是"能识别并消除 UB"，不是"跑出正确结果"。
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import shutil
import sys
import tempfile
from dataclasses import dataclass, field

try:
    from sandbox_win import Limits, RunResult
except ImportError:  # Linux/macOS：判定原语（常量/Verdict/compare_output）可用，
    # 但本模块的「编译运行」路径依赖 Windows 沙箱——Linux 平台的执行请走
    # judge/linux_judge.py（ExecutionBackend）。见 docs/移植说明.md 与 L10 架构文档。
    Limits = None  # type: ignore[assignment]
    RunResult = None  # type: ignore[assignment]
try:
    from sandbox_win import run as sandbox_run
except ImportError:  # Linux/macOS：见上方软导入说明
    sandbox_run = None  # type: ignore[assignment]
from toolchain import Toolchain, asan_env_options, detect, make_env

# =============================================================================
# 判定码
# =============================================================================

AC = "AC"  # Accepted        通过
WA = "WA"  # Wrong Answer    答案错误（含检测到 UB）
CE = "CE"  # Compile Error   编译失败
RE = "RE"  # Runtime Error   运行时崩溃
TLE = "TLE"  # Time Limit     超时
MLE = "MLE"  # Memory Limit   超内存
OLE = "OLE"  # Output Limit   输出超量
SE = "SE"  # System Error    判题系统自身出错（编译器缺失、DLL 缺失等）

# RUN 不是"通过"，而是"跑起来了，但这题不判对错"。
# 用于**开放式实验**（报告 3F / 第 10 节 X2）：任务是"改成你自己的内容"这类
# 没有唯一答案的实验，只要求能跑起来并让用户看到输出。前端不该给它打 AC 徽章。
RUN = "RUN"  # Ran OK          已运行（不判定）

VERDICT_TEXT = {
    RUN: "已运行",
    AC: "通过",
    WA: "答案错误",
    CE: "编译失败",
    RE: "运行时错误",
    TLE: "超时",
    MLE: "超出内存限制",
    OLE: "输出超出限制",
    SE: "判题系统错误",
}

DEFAULT_TIME_LIMIT_MS = 2000
DEFAULT_MEM_LIMIT_MB = 512

# 章节 JSON 里的 mode 用驼峰（compileFail / predictOutput），
# Python 惯例用下划线（compile_fail / predict_output）。
# 这里做一次归一化，两种写法都接受——内容产出方（沙箱会话）不用迁就判题引擎。
#
# **题型能力的单一事实源是 mode_registry.py**（架构审查第二条：新增题型原来
# 要手工同步 13 处，已实测两起静默漂移）。MODE_ALIASES 与下面各 mode 集合
# 都从注册表派生 —— 加题型只改注册表 + src/modes.js 两处（SYNC-ANCHOR）。
import mode_registry  # noqa: E402

MODE_ALIASES = mode_registry.alias_map()

# 需要用户改动代码才能通过的题型（内容健康检查里的"baseline must fail"针对它们）
CODE_EDITING_MODES = mode_registry.code_modes()

# 用户在答案框里填预测输出的题型
PREDICT_MODES = mode_registry.predict_modes()

# 选择题：用户在选项里挑一个，后端比对正确下标
CHOICE_MODES = mode_registry.choice_modes()

# 只运行不判定的题型（开放式实验）
RUN_MODES = {"run"}

# ── 新方向的题型（Linux / Docker / Infra）──────────────────────────────────
# 判题强度分三层，**每层在题面上都要写明**（用户 2026-09 拍板）：
#   ① 真跑：`shell` —— 用户写的 sh 脚本在本机真执行（busybox-w32，不用 WSL）
#   ② 静态语义判定：`config` —— 解析配置文件后按断言集判，**不真跑容器**
#   ③ 模拟/状态机：留给后续的 diagnose / embedded / toolcall（还没实现）
# 为什么分三层而不是一律真跑：软件承诺"不往系统里装东西"，Docker/K8s/systemd
# 在用户机器上根本没有；与其假装判过，不如把"判的是什么"写清楚。
SHELL_MODES = {"shell"}
CONFIG_MODES = {"config"}
# 命令行版的"只跑不判"（实验用）：与 C++ 的 `run` 同义，只是执行的是 sh 脚本
SHELL_RUN_MODES = {"shell_run"}
# 排障诊断：答案是一份**结构化的判断**（现象 → 证据 → 处置），按要点给分。
# 这是三种判题强度里的第三种（模拟/结构化），也是 Infra 方向的主战场：
# 真实排障考的不是"能不能背出命令"，而是"看哪条证据、得出什么结论"。
DIAGNOSE_MODES = {"diagnose"}
# 嵌入式：三种判据叠加（都是"真跑"级别的证据，不是纸面选择题）
#   ① 目标平台**真交叉编译**（clang --target=armv6m-none-eabi -ffreestanding，只编译不链接）
#   ② **objdump 断言**：看生成的指令里有没有除法/浮点（Cortex-M0 没有硬件除法器）、代码多大
#   ③ **主机侧寄存器仿真**：题面给一份假外设头（寄存器映射成数组 + 事件驱动），
#      把同一份代码在主机上编译运行，判"寄存器写序列"（这才是嵌入式真正的行为判据）
EMBED_MODES = {"embed"}
# Agent / Infra 的代码题：在本机**真跑一段 Python**（judge 自带的那份解释器），
# 判 stdout + 文件副作用。为什么需要它：
#   · Agent 方向要考的是"写得出 agent 循环 / 解析工具调用 / 实现 MCP server / 切分与检索"，
#     这些用选择题和配置题考不出来 —— 只有真跑用户写的代码才算"真判"（判题强度①）；
#   · 它和 `shell` 同构（同一套沙箱、同一套多测试组、同样的文件副作用判定），
#     区别只是解释器与"非零退出码=脚本出错"这一条语义。
# ⚠️ 禁网：沙箱本来就没有网络，所以 Agent 题一律用**假模型/固定响应**来判 ——
#    这也让题目不依赖任何 API key，任何人 clone 下来就能跑（见 docs/开发者说明.md）。
PYTHON_MODES = {"python"}
# Python 版的"只跑不判"（实验用）：与 `shell_run` 同义 —— Python 实验不能走 C++ 的
# `run`（那个模式要编译器）。实验的判题配置写在 `check.mode` 里。
PYTHON_RUN_MODES = {"python_run"}
NEW_TRACK_MODES = (SHELL_MODES | CONFIG_MODES | SHELL_RUN_MODES | DIAGNOSE_MODES
                   | EMBED_MODES | PYTHON_MODES | PYTHON_RUN_MODES)

# 全部合法题型 —— 直接取注册表全集（加题型时这里自动跟上，不会漏登记）
ALL_MODES = set(mode_registry.CANONICAL)
# 自检：上面各分组的并集必须等于注册表全集（分组漏了新题型立刻炸在 import 时）
_missing = ALL_MODES - (CODE_EDITING_MODES | PREDICT_MODES | CHOICE_MODES | RUN_MODES
                        | NEW_TRACK_MODES)
if _missing:
    raise RuntimeError(f"engine 的题型分组漏了注册表题型：{sorted(_missing)}")

# 支持多测试（tests 数组）的题型 —— 这些是"编译运行后比对输出"的题
MULTI_TEST_MODES = {"output", "asan", "shell", "python"}


def normalize_mode(mode: str) -> str:
    """把各种写法的 mode 归一化成标准形式。"""
    key = (mode or "").strip().lower()
    return MODE_ALIASES.get(key, key)



# 编译阶段给得宽松些：模板递归、头文件多的时候会比运行慢得多
COMPILE_WALL_MS = 30000
COMPILE_MEM_MB = 2048
COMPILE_OUTPUT_BYTES = 128 * 1024

# 0xC0000135 = STATUS_DLL_NOT_FOUND
STATUS_DLL_NOT_FOUND = 0xC0000135


@dataclass
class Verdict:
    """一次判题的结果，直接序列化成 JSON 返回给前端。"""

    verdict: str = SE
    message: str = ""
    stdout: str = ""
    stderr: str = ""
    compile_output: str = ""
    time_ms: int = 0
    peak_mem_mb: float = 0.0
    crash_hint: str = ""
    sanitizer_report: str = ""
    # predictOutput 用：程序真实输出。只在提交之后才回传，用来讲解
    actual_output: str = ""
    # predictOutput 用：判错时的一句话提示，不泄露完整答案
    short_hint: str = ""
    # multipleChoice 用：正确选项下标。**只在提交之后**回传，供前端高亮
    correct_index: int | None = None

    def to_dict(self) -> dict:
        return {
            "verdict": self.verdict,
            "verdictText": VERDICT_TEXT.get(self.verdict, self.verdict),
            "message": self.message,
            "stdout": self.stdout,
            "stderr": self.stderr,
            "compileOutput": self.compile_output,
            "timeMs": self.time_ms,
            "peakMemMb": self.peak_mem_mb,
            "crashHint": self.crash_hint,
            "sanitizerReport": self.sanitizer_report,
            "actualOutput": self.actual_output,
            "shortHint": self.short_hint,
            "correctIndex": self.correct_index,
        }


# =============================================================================
# 输出比对
# =============================================================================


def _normalize(text: str) -> str:
    """规范化输出：去掉每行行尾空白和结尾多余空行。

    判题器不应该因为"多了一个换行"或"行尾多了个空格"判 WA——那不是知识点。
    """
    lines = [ln.rstrip() for ln in text.replace("\r\n", "\n").split("\n")]
    while lines and lines[-1] == "":
        lines.pop()
    while lines and lines[0] == "":
        lines.pop(0)
    return "\n".join(lines)


def compare_output(actual: str, expected: str, float_tol: float | None) -> tuple[bool, str]:
    """比对输出。返回 (是否通过, 差异说明)。

    有 float_tol 时按数值逐 token 比较（浮点题专用）；否则按规范化后的文本比较。
    """
    a = _normalize(actual)
    e = _normalize(expected)

    if float_tol is None:
        if a == e:
            return True, ""
        return False, _diff_hint(a, e)

    a_tokens = a.split()
    e_tokens = e.split()
    if len(a_tokens) != len(e_tokens):
        return False, f"输出项数不一致：期望 {len(e_tokens)} 个，实际 {len(a_tokens)} 个"

    for i, (av, ev) in enumerate(zip(a_tokens, e_tokens)):
        try:
            af, ef = float(av), float(ev)
        except ValueError:
            if av != ev:
                return False, f"第 {i + 1} 项不一致：期望 {ev!r}，实际 {av!r}"
            continue
        if abs(af - ef) > float_tol:
            return False, f"第 {i + 1} 项超出容差：期望 {ev}，实际 {av}（容差 {float_tol}）"
    return True, ""


def _diff_hint(actual: str, expected: str) -> str:
    """给出"第一行哪里不一样"的人话提示，比甩两份全文好用得多。"""
    a_lines = actual.split("\n")
    e_lines = expected.split("\n")
    for i in range(max(len(a_lines), len(e_lines))):
        av = a_lines[i] if i < len(a_lines) else "<无这一行>"
        ev = e_lines[i] if i < len(e_lines) else "<无这一行>"
        if av != ev:
            return f"第 {i + 1} 行不一致：期望 {ev!r}，实际 {av!r}"
    return "输出与期望不一致"


def _predict_hint(answer: str, expected: str) -> str:
    """predictOutput 判错时的一句话提示。

    刻意**不给出期望值**——直接告诉答案，"先押注再看结果"的教学价值就没了。
    只提示"哪一行不对 / 行数不对"，把思考留给用户。
    """
    a = _normalize(answer).split("\n")
    e = _normalize(expected).split("\n")
    if len(a) != len(e):
        return f"输出的行数不对（你写了 {len(a)} 行）。再数一下程序一共打印了几行。"
    for i, (x, y) in enumerate(zip(a, e)):
        if x != y:
            return f"第 {i + 1} 行不对。再算算这一行实际会打印什么。"
    return "内容不完全一致，注意行尾空格和末尾空行。"


def _judge_predict_output(
    *,
    code: str,
    expected: str,
    answer: str,
    stdin_data: str = "",
    time_limit_ms: int = DEFAULT_TIME_LIMIT_MS,
    toolchain: Toolchain,
    workdir_root: str | None = None,
) -> Verdict:
    """predictOutput 模式：代码只读，用户在答案框里填自己预测的 stdout。

    和 output 模式的本质区别：
      output          = 用户改代码，让程序输出正确答案
      predictOutput   = 代码不能改，用户必须**先押注**再提交

    为什么必须拆开（这是之前踩的坑）：
      把"预测输出"题做成 output 模式时，初始代码本身就能跑出 expected，
      用户点一下判题直接 AC，什么都没学到。

    判据要点：
      - 空答案必须判 WA（不做就等于没做）
      - 提交前绝不把 expected 送到前端（前端压根拿不到这个字段）
      - 判错只给位置提示，不泄露答案
      - 判对后才回传真实输出 + 题解
      - 顺带跑一遍示例程序，验证题目内容本身没错
    """
    if not (answer or "").strip():
        return Verdict(WA, "请先在答案框里填写你预测的输出，再提交。")

    workdir = tempfile.mkdtemp(prefix="cpppredict_", dir=workdir_root)
    real_stdout = ""
    try:
        with open(os.path.join(workdir, "main.cpp"), "w", encoding="utf-8", newline="\n") as fh:
            fh.write(code)

        build = _compile(toolchain, workdir, "output")
        if build.error:
            return Verdict(SE, build.error)
        if not build.ok:
            # 示例代码自己编译不过 —— 内容错误，不是用户的错
            return Verdict(
                SE,
                "这道题的示例代码本身编译失败（内容错误，请修章节 JSON）：\n" + build.compile_output[:600],
            )

        exe = os.path.join(workdir, "main.exe")
        res = sandbox_run(
            [exe],
            limits=Limits(
                wall_time_ms=max(time_limit_ms + 2000, 3000),
                cpu_time_ms=time_limit_ms,
                memory_mb=DEFAULT_MEM_LIMIT_MB,
                output_bytes=64 * 1024,
                max_processes=8,
            ),
            stdin_data=stdin_data,
            cwd=workdir,
            env=make_env(toolchain),
        )
        if res.error:
            return Verdict(SE, res.error)
        real_stdout = res.stdout
    finally:
        shutil.rmtree(workdir, ignore_errors=True)

    # 内容自检：示例程序的真实输出必须等于 expected，否则题目本身是错的
    content_ok, _ = compare_output(real_stdout, expected, None)
    if not content_ok:
        return Verdict(
            SE,
            "这道题的示例代码实际输出与 expected 不一致（内容错误）。\n"
            f"真实输出：{_normalize(real_stdout)!r}\n"
            f"expected：{_normalize(expected)!r}",
            actual_output=real_stdout,
        )

    ok, _ = compare_output(answer, expected, None)
    if ok:
        return Verdict(AC, "预测正确 ✅", actual_output=real_stdout)
    return Verdict(
        WA,
        "预测不对。" + _predict_hint(answer, expected),
        short_hint=_predict_hint(answer, expected),
    )


def exercise_items(ch: dict) -> list:
    """一个章节文件里的「题目」：普通章节取 exercises[]，挑战文件取 challenges[]。

    所有工具都从这里取，别各自判断 —— 否则漏一处就会出现
    「挑战文件检查通过但什么都没查」这种假绿灯。
    """
    ex = ch.get("exercises")
    if isinstance(ex, list) and ex:
        return ex
    chs = ch.get("challenges")
    if isinstance(chs, list):
        return chs
    return []


def correct_choice_index(choices: list | None) -> int | None:
    """选择题：找出 `correct: true` 的下标。找不到返回 None。"""
    for i, c in enumerate(choices or []):
        if isinstance(c, dict) and c.get("correct"):
            return i
    return None


def judge_exercise(ex: dict, *, answer: str = "", toolchain: Toolchain | None = None) -> Verdict:
    """**从章节 JSON 里的一道题直接判题——所有调用方都走这里。**

    存在的理由：有些折算规则只有一处应该知道。比如「选择题的 expected
    是正确选项下标、而章节 JSON 里根本不写 expected」——
    如果 Rust、健康检查、结构校验各写一遍，早晚会有一处漏掉，
    表现就是"明明是好题却被报 SE"。
    """
    mode = normalize_mode(ex.get("mode", ""))
    choices = ex.get("choices") or []
    expected = ex.get("expected", "") or ""

    if mode == "multiple_choice":
        ci = correct_choice_index(choices)
        expected = "" if ci is None else str(ci)

    return judge_case(
        mode=mode,
        code=ex.get("code", "") or "",
        expected=expected,
        stdin_data=ex.get("stdin", "") or "",
        answer=answer,
        choices=choices,
        tests=ex.get("tests") or [],
        float_tol=ex.get("float_tol", ex.get("floatTol")),
        toolchain=toolchain,
        # 新方向（shell / config）：题面给定的文件树、文件名、断言集
        files=ex.get("files") or {},
        asserts=ex.get("asserts") or [],
        target_file=ex.get("file", "") or "",
    )


def _judge_multiple_choice(*, expected: str, answer: str, choices: list) -> Verdict:
    """选择题（含判断题）。

    `expected` 是**正确选项的下标**——Rust 侧读 `choices[].correct` 折算好后传进来，
    这样判题就退化成一次整数比较，不用把整个选项数组的逻辑搬到这里。

    反馈设计（对应报告 6.4「每个错误选项为什么错」）：
      - 答错时只回传"你选的那一项为什么错"（`shortHint`），
        不告诉用户正确答案是哪个 —— 让ta自己再想一次
      - 提交后才通过 `correctIndex` 回传正确下标，前端据此高亮
    """
    ans = (answer or "").strip()
    if not ans:
        return Verdict(WA, "请先选择一个选项再提交。")

    try:
        chosen = int(ans)
    except ValueError:
        return Verdict(SE, f"选择题的答案应该是选项下标，收到 {ans!r}")

    if not choices:
        return Verdict(SE, "这道选择题没有配置 choices 数组")
    if not 0 <= chosen < len(choices):
        return Verdict(SE, f"选项下标越界：{chosen}（共 {len(choices)} 项）")

    try:
        correct = int((expected or "").strip())
    except ValueError:
        return Verdict(SE, "这道选择题没有配置正确选项（choices 里缺少 correct: true）")

    if chosen == correct:
        return Verdict(AC, "选对了", correct_index=correct)

    why = ""
    c = choices[chosen]
    if isinstance(c, dict):
        why = (c.get("why") or "").strip()

    v = Verdict(WA, "选错了。再看看这一项为什么不对。", correct_index=correct)
    v.short_hint = why
    return v


def _looks_like_sanitizer(stderr: str) -> bool:
    """判断这段 stderr 是不是 sanitizer 报告。"""
    markers = (
        "AddressSanitizer",
        "runtime error:",
        "UndefinedBehaviorSanitizer",
        "SUMMARY: ",
        "LeakSanitizer",
    )
    return any(m in stderr for m in markers)


# =============================================================================
# 编译
# =============================================================================


@dataclass
class BuildResult:
    ok: bool
    compile_output: str = ""
    error: str = ""


def _build_command(tc: Toolchain, source: str, exe: str, mode: str) -> list[str]:
    cmd = [tc.cxx, "-std=c++20", "-O0", "-g", source, "-o", exe]
    if mode == "asan":
        # -fno-omit-frame-pointer 让 ASan 能打出可读的调用栈
        cmd += ["-fsanitize=address,undefined", "-fno-omit-frame-pointer"]
    # 编译期就暴露 UB/越界：这些警告不进判定，但会随 compile_output 展示，
    # 帮用户理解"为什么这段代码在编译期就有问题"
    cmd += ["-Wall", "-Wextra"]
    return cmd


def _compile(tc: Toolchain, workdir: str, mode: str) -> BuildResult:
    source = os.path.join(workdir, "main.cpp")
    exe = os.path.join(workdir, "main.exe")

    cmd = _build_command(tc, "main.cpp", "main.exe", mode)
    limits = Limits(
        wall_time_ms=COMPILE_WALL_MS,
        cpu_time_ms=COMPILE_WALL_MS,
        memory_mb=COMPILE_MEM_MB,
        output_bytes=COMPILE_OUTPUT_BYTES,
        max_processes=16,
    )
    env = make_env(tc)
    if mode == "asan":
        env.update(asan_env_options(tc))

    res = sandbox_run(cmd, limits=limits, cwd=workdir, env=env)

    if res.error:
        return BuildResult(False, error=res.error)

    output = (res.stdout + res.stderr).strip()

    if res.killed_reason in ("wall", "cpu"):
        return BuildResult(False, compile_output=output, error="编译超时（可能是模板无限递归展开）")
    if res.killed_reason == "memory":
        return BuildResult(False, compile_output=output, error="编译器内存耗尽")
    if res.killed_reason == "output":
        return BuildResult(False, compile_output=output, error="编译输出过多（模板报错爆炸）")

    if res.exit_code != 0 or not os.path.isfile(exe):
        return BuildResult(False, compile_output=output)

    return BuildResult(True, compile_output=output)


# =============================================================================
# 主入口
# =============================================================================


# =============================================================================
# 新方向：`shell`（真跑）与 `config`（静态语义判定）
#
# 用户 2026-09 拍板的三条：
#   ① 选择题降级为「概念核验」，动手题占大头；
#   ② 判题强度分三层，**题面上必须写明这题属于哪一层**；
#   ③ Linux 命令要能**真跑**（引 busybox-w32，不装 WSL）。
# 这一段就是①②③在引擎侧的落点：两种新题型 + 一句 SE 里说清"缺什么"。
# =============================================================================

# 真跑 shell 的时间上限比 C++ 题宽：管道 + 一堆小进程在 Windows 上启动慢，
# 而且学生写的常见是 `find | xargs` 这种会起很多进程的东西。
SHELL_DEFAULT_TIME_MS = 10000


def find_busybox() -> str | None:
    """找 busybox-w32 可执行文件。

    查找顺序（**第一处命中即用**，顺序本身就是"优先级"的说明）：
      1. `BAZHOU_BUSYBOX` —— 显式指定，测试与排查用（也让我们能在探针里故意指错，
         验证"缺 busybox 时报 SE 而不是静默判错"）；
      2. 判题运行时目录下的 `busybox/busybox.exe` —— **发布版走的就是这条**
         （随"现在准备判题环境"一起装到软件目录，不碰系统环境）；
      3. 环境变量 `BAZHOU_RUNTIME_DIR` 指的目录（Rust 侧会设这个）；
      4. PATH 里的 `busybox`（开发机自己装过的情况）。
    """
    explicit = (os.environ.get("BAZHOU_BUSYBOX") or "").strip()
    if explicit:
        return explicit if os.path.isfile(explicit) else None

    roots = []
    rt = (os.environ.get("BAZHOU_RUNTIME_DIR") or "").strip()
    if rt:
        roots.append(rt)
    # 仓库里开发用的运行时（`runtime/` 被 .gitignore 忽略，不随包发）
    here = os.path.dirname(os.path.abspath(__file__))
    roots.append(os.path.join(os.path.dirname(here), "runtime"))
    for r in roots:
        for name in ("busybox.exe", "busybox"):
            p = os.path.join(r, "busybox", name)
            if os.path.isfile(p):
                return p

    found = shutil.which("busybox") or shutil.which("busybox.exe")
    return found or None


def _judge_shell(
    *,
    code: str,
    files: dict,
    tests: list,
    expected: str,
    stdin_data: str,
    time_limit_ms: int,
    mem_limit_mb: int,
    toolchain: Toolchain,
    workdir_root: str | None,
    compare: bool = True,
) -> Verdict:
    """在本机真跑一段 sh 脚本（busybox-w32），判 stdout。**判题强度：真跑。**

    为什么用 busybox 而不是 cmd/PowerShell：这些题教的是 Linux 命令行
    （管道、文本处理、find/xargs），用 Windows 的命令解释器教不出来；
    而 WSL 明确不在本软件的准备范围内（见 docs/供应商约定）。busybox-w32 是
    单个 0.7 MB 的 exe、原生 Windows 程序，随判题环境装到软件目录即可。

    ⚠️ 诚实边界（题面里也要写）：busybox 能真跑命令与管道，但**没有真实内核**——
    权限位（chmod 只改标记）、systemd/cron、网络栈、包管理都不是真的。
    这些内容要么走模拟判定，要么在题面里明确"需要你自己在真机上做"。
    """
    bb = find_busybox()
    if not bb:
        return Verdict(
            SE,
            "判题环境里没有 busybox（Linux 命令题的运行器）。"
            "在「设置 → 判题环境」里点一次「现在准备判题环境」即可；"
            "如果你在开发本仓库，见 docs/开发者说明.md 里 busybox 的放置位置。",
        )

    tests = tests or []
    if not (code or "").strip():
        return Verdict(WA, "还没有写内容。题目要求的是能跑出正确输出的命令或脚本。")
    # 只跑不判（实验）：不需要测试组，跑一次把输出给用户看就是结果
    if not compare:
        cases = tests or [{"name": "运行", "stdin": stdin_data, "expected": ""}]
    elif not tests and expected == "" and not stdin_data:
        return Verdict(SE, "这道 shell 题没有任何测试组（tests 为空）")
    else:
        cases = tests or [{"name": "本题", "stdin": stdin_data, "expected": expected}]

    limits = Limits(
        wall_time_ms=max(time_limit_ms + 3000, 5000),
        cpu_time_ms=time_limit_ms,
        memory_mb=mem_limit_mb,
        output_bytes=256 * 1024,
        max_processes=16,      # 管道 + xargs 会起不少进程
    )
    env = make_env(toolchain) if toolchain else dict(os.environ)
    # 让 PATH 里也能直接用到 busybox：有些写法（`grep` 直接调）依赖这一点，
    # 而 busybox-w32 支持把所在目录当 applet 目录。
    env["PATH"] = os.path.dirname(bb) + os.pathsep + env.get("PATH", "")

    # ⚠️ **每组测试都用全新的工作目录**。两条理由，都是会咬人的：
    #   ① 组间状态污染：第一组里脚本 `mkdir out` 之后，第二组就"看见"了上一组的
    #      产物 —— 判出来的结果取决于组的顺序，这种判题没法解释、也没法复现；
    #   ② shell 题的数据常常就是**文件树本身**，所以 case 可以带自己的 `files`
    #      （与题面级 files 合并，同名覆盖）：多组测试 = 换一组数据再试一次。
    for idx, case in enumerate(cases, 1):
        label = case.get("name") or f"第 {idx} 组"
        workdir = tempfile.mkdtemp(prefix=f"shelljudge{idx}_", dir=workdir_root)
        try:
            merged = dict(files or {})
            merged.update(case.get("files") or {})
            for rel, content in merged.items():
                target = os.path.join(workdir, rel.replace("/", os.sep))
                parent = os.path.dirname(target)
                if parent:
                    os.makedirs(parent, exist_ok=True)
                with open(target, "w", encoding="utf-8", newline="\n") as fh:
                    fh.write(content)

            with open(os.path.join(workdir, "main.sh"), "w",
                      encoding="utf-8", newline="\n") as fh:
                fh.write(code)

            res = sandbox_run(
                # 每个测试组可以带自己的**脚本参数**（`args`）：真实脚本都要接收参数，
                # 而"同一段脚本换不同参数跑"正是参数类题目的判据（LX1-12 用它）。
                [bb, "sh", "main.sh", *[str(a) for a in (case.get("args") or [])]],
                limits=limits,
                stdin_data=case.get("stdin", "") or "",
                cwd=workdir,
                env=env,
            )
            if res.error:
                return Verdict(SE, res.error)

            if res.killed_reason == "memory":
                return Verdict(MLE, f"内存超出限制（峰值 {res.peak_mem_mb} MB）", stdout=res.stdout)
            if res.killed_reason in ("wall", "cpu"):
                return Verdict(
                    TLE,
                    f"超时（限制 {time_limit_ms} ms）。常见原因：脚本里有等待输入的"
                    "命令（如直接 `cat` 不带参数）、循环没有终止条件、或起了不会结束的进程。",
                    stdout=res.stdout,
                )
            if res.killed_reason == "output":
                return Verdict(OLE, "输出内容过多，可能是死循环在疯狂打印", stdout=res.stdout)

            want = _normalize_shell_output(case.get("expected", "") or "")
            got = _normalize_shell_output(res.stdout or "")
            if compare and got != want:
                # `actualOutput` 是前端已经会渲染的字段（原来给 predictOutput 用），
                # 这里复用它把"你的输出 vs 期望输出"摆在判定块里——shell 题排错全靠这个。
                return Verdict(
                    WA,
                    f"测试「{label}」没过（第 {idx}/{len(cases)} 组）。"
                    "下面「程序的真实输出」是你的脚本实际打出来的。",
                    stdout=res.stdout,
                    stderr=res.stderr,
                    actual_output=case.get("expected", ""),
                )

            # ── 文件树副作用（可选）─────────────────────────────────────
            # 命令行的另一半工作是**改文件**（重定向、改名、建目录），只比对 stdout
            # 判不出来。判据写在每组测试的 `expectFiles` 里：
            #   [{"path": "out/errors.txt", "exists": true},
            #    {"path": "data/old.txt",  "exists": false},
            #    {"path": "notes/todo.md", "content": "buy milk\n"}]
            # content 也走同一套归一化（行尾空白与末尾空行不影响判定）。
            bad_files = []
            for spec in (case.get("expectFiles") or []):
                rel = spec.get("path", "")
                target = os.path.join(workdir, rel.replace("/", os.sep))
                exists = os.path.isfile(target)
                if spec.get("exists") is False:
                    if exists:
                        bad_files.append(f"{rel} 应该不存在，但它还在")
                    continue
                if not exists:
                    bad_files.append(f"{rel} 不存在（期望它被创建/保留）")
                    continue
                if "content" in spec:
                    with open(target, encoding="utf-8", errors="replace") as fh:
                        actual = fh.read()
                    if _normalize_shell_output(actual) != _normalize_shell_output(spec["content"]):
                        bad_files.append(f"{rel} 的内容不对（实际 {len(actual)} 字节）")
            if bad_files:
                return Verdict(
                    WA,
                    f"测试「{label}」的命令输出对了，但**文件没处理对**（第 {idx}/{len(cases)} 组）：\n"
                    + "\n".join(f"· {b}" for b in bad_files),
                    stdout=res.stdout,
                    stderr=res.stderr,
                )

            last = res
        finally:
            shutil.rmtree(workdir, ignore_errors=True)

    # 只跑不判（实验）：跑完就是结果 —— 输出本身就是用户要看的东西
    if not compare:
        return Verdict(
            RUN,
            "运行完成。这个实验不判对错 —— 看你自己的输出就行。",
            stdout=last.stdout,
            stderr=last.stderr,
            time_ms=last.time_ms,
            peak_mem_mb=last.peak_mem_mb,
        )

    # 非零退出码但输出全对：算通过，但提示一句（管道里最后一条命令的退出码
    # 常常是"没找到"之类，不能因此判错）
    if last.exit_code != 0:
        return Verdict(
            AC,
            f"全部 {len(cases)} 组测试通过 ✅（注意：脚本退出码是 {last.exit_code}，"
            "管道最后一条命令返回非零；不影响判定）",
            stdout=last.stdout,
            time_ms=last.time_ms,
        )
    return Verdict(
        AC,
        f"全部 {len(cases)} 组测试通过 ✅",
        stdout=last.stdout,
        time_ms=last.time_ms,
        peak_mem_mb=last.peak_mem_mb,
    )


def _normalize_shell_output(s: str) -> str:
    """shell 题比对前的归一化。

    只做两件**不改变语义**的事（都是为了不让无关差异判错）：
      · CRLF → LF（Windows 上的输出/文件读出来是 \\r\\n）
      · 去掉每行行尾空格 + 去掉整体末尾的空白行
    **不做**的事：不改大小写、不忽略中间空行、不排序 —— 那些差异是答案的一部分。
    """
    s = (s or "").replace("\r\n", "\n").replace("\r", "\n")
    lines = [ln.rstrip() for ln in s.split("\n")]
    while lines and lines[-1] == "":
        lines.pop()
    return "\n".join(lines)


PYTHON_DEFAULT_TIME_MS = 10000


def find_python() -> str | None:
    """找**跑用户 Python 代码**用的解释器。

    查找顺序（第一处命中即用，顺序本身就是优先级说明）：
      1. `BAZHOU_COURSE_PYTHON` —— 显式指定。测试与探针用它可以**故意指错**，
         用来验证"缺解释器时报 SE 而不是把题判成 WA"（这条断言必须能开火）；
      2. `sys.executable` —— **正在跑判题引擎的这个 Python**。这是最稳的一条：
         判题本身就跑在 Python 上，能跑引擎就一定能跑学员的代码，且版本一致；
      3. PATH 里的 `python` / `python3`（`sys.executable` 为空时才会走到，例如被冻结打包）。

    为什么要"用判题自带的解释器"而不是另装一个：软件承诺不往用户系统里装东西，
    多一个解释器就多一份探测、下载、版本漂移的麻烦。学员代码只许用**标准库**
    （嵌入版 Python 没有 pip），这一点写在题面里。
    """
    explicit = (os.environ.get("BAZHOU_COURSE_PYTHON") or "").strip()
    if explicit:
        return explicit if os.path.isfile(explicit) else None

    exe = (sys.executable or "").strip()
    if exe and os.path.isfile(exe):
        return exe
    found = shutil.which("python") or shutil.which("python3")
    return found or None


def _judge_python(
    *,
    code: str,
    files: dict,
    tests: list,
    expected: str,
    stdin_data: str,
    time_limit_ms: int,
    mem_limit_mb: int,
    toolchain: Toolchain,
    workdir_root: str | None,
    compare: bool = True,
) -> Verdict:
    """在本机真跑一段 Python（判题自带解释器），判 stdout 与文件副作用。**判题强度：真跑。**

    与 `_judge_shell` 同构（同样的多测试组、每组一个全新工作目录、`expectFiles` 判定），
    差别只有两条，都是刻意的：
      · **非零退出码 = 脚本出错**（Python 里这意味着抛了异常）。shell 那边非零退出码常常
        只是管道最后一条命令没匹配到，所以 shell 判 AC；Python 必须判 WA 并把 stderr 给出来。
      · **禁网**：沙箱没有网络，所以涉及模型的题一律用假模型/固定响应（见题面的 files）。
    """
    py = find_python()
    if not py:
        return Verdict(
            SE,
            "判题环境里没有可用的 Python 解释器（Agent / Infra 的代码题要用它跑）。"
            "正常情况下判题引擎自己就跑在 Python 上，出现这条说明环境被改过；"
            "开发仓库里可以用 BAZHOU_COURSE_PYTHON 指定一个解释器。",
        )

    tests = tests or []
    if not (code or "").strip():
        return Verdict(WA, "还没有写内容。这道题要交的是一段能跑出正确输出的 Python 代码。")
    # 只跑不判（实验）：跑一次把输出给用户看就是结果
    if not compare:
        cases = tests or [{"name": "运行", "stdin": stdin_data, "expected": ""}]
    elif not tests and expected == "" and not stdin_data:
        return Verdict(SE, "这道 python 题没有任何测试组（tests 为空）")
    else:
        cases = tests or [{"name": "本题", "stdin": stdin_data, "expected": expected}]

    limits = Limits(
        wall_time_ms=max(time_limit_ms + 3000, 5000),
        cpu_time_ms=time_limit_ms,
        memory_mb=mem_limit_mb,
        output_bytes=256 * 1024,
        max_processes=8,
    )
    base_env = make_env(toolchain) if toolchain else dict(os.environ)
    env = dict(base_env)
    # 学员代码在不同机器上的行为要一致：UTF-8 输入输出、不写 .pyc、不打缓冲
    # （不打缓冲是为了让"边跑边看输出"和崩溃前的输出都能拿到 —— 排错全靠它）
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONUNBUFFERED"] = "1"
    # 让 `import 帮助模块` 能直接 import 到题面 files 里给的模块
    env["PYTHONPATH"] = "."

    for idx, case in enumerate(cases, 1):
        label = case.get("name") or f"第 {idx} 组"
        workdir = tempfile.mkdtemp(prefix=f"pyjudge{idx}_", dir=workdir_root)
        try:
            # 每组测试一个全新目录：组间不污染（第一组写出去的产物，第二组不该看见）。
            # 题面级 files（假模型、样例数据）+ 本组 files 合并，同名覆盖 ——
            # 这正是 Agent 题"换一组模型响应再试一次"的做法。
            merged = dict(files or {})
            merged.update(case.get("files") or {})
            for rel, content in merged.items():
                target = os.path.join(workdir, rel.replace("/", os.sep))
                parent = os.path.dirname(target)
                if parent:
                    os.makedirs(parent, exist_ok=True)
                with open(target, "w", encoding="utf-8", newline="\n") as fh:
                    fh.write(content)

            with open(os.path.join(workdir, "main.py"), "w",
                      encoding="utf-8", newline="\n") as fh:
                fh.write(code)

            res = sandbox_run(
                [py, "main.py", *[str(a) for a in (case.get("args") or [])]],
                limits=limits,
                stdin_data=case.get("stdin", "") or "",
                cwd=workdir,
                env=env,
            )
            if res.error:
                return Verdict(SE, res.error)

            if res.killed_reason == "memory":
                return Verdict(MLE, f"内存超出限制（峰值 {res.peak_mem_mb} MB）", stdout=res.stdout)
            if res.killed_reason in ("wall", "cpu"):
                return Verdict(
                    TLE,
                    f"超时（限制 {time_limit_ms} ms）。常见原因：`while True` 没有出口、"
                    "等待输入的 `input()` 而测试组没给输入、或者递归没有终止条件。",
                    stdout=res.stdout,
                )
            if res.killed_reason == "output":
                return Verdict(OLE, "输出内容过多，可能是死循环在疯狂打印", stdout=res.stdout)

            want = _normalize_shell_output(case.get("expected", "") or "")
            got = _normalize_shell_output(res.stdout or "")
            if compare and got != want:
                return Verdict(
                    WA,
                    f"测试「{label}」没过（第 {idx}/{len(cases)} 组）。"
                    "下面「程序的真实输出」是你的代码实际打出来的。",
                    stdout=res.stdout,
                    stderr=res.stderr,
                    actual_output=case.get("expected", ""),
                )

            # 非零退出码：Python 里这就是抛异常了。输出即便对，也说明代码不干净
            # （常见于 `sys.exit(1)`、异常被吞掉一半、或最后一条 print 之后崩了）。
            if res.exit_code != 0:
                return Verdict(
                    WA,
                    f"测试「{label}」的输出了对，但脚本**以退出码 {res.exit_code} 结束**"
                    "（Python 里通常意味着抛了异常）。看下面的 stderr。",
                    stdout=res.stdout,
                    stderr=res.stderr,
                )

            # ── 文件副作用（可选）：Agent 题常要求"把 trace / 报告写到文件里" ──
            bad_files = []
            for spec in (case.get("expectFiles") or []):
                rel = spec.get("path", "")
                target = os.path.join(workdir, rel.replace("/", os.sep))
                exists = os.path.isfile(target)
                if spec.get("exists") is False:
                    if exists:
                        bad_files.append(f"{rel} 应该不存在，但它还在")
                    continue
                if not exists:
                    bad_files.append(f"{rel} 不存在（期望它被创建/保留）")
                    continue
                if "content" in spec:
                    with open(target, encoding="utf-8", errors="replace") as fh:
                        actual = fh.read()
                    if _normalize_shell_output(actual) != _normalize_shell_output(spec["content"]):
                        bad_files.append(f"{rel} 的内容不对（实际 {len(actual)} 字节）")
                if "contains" in spec:
                    with open(target, encoding="utf-8", errors="replace") as fh:
                        actual = fh.read()
                    if spec["contains"] not in actual:
                        bad_files.append(f"{rel} 里找不到 {spec['contains']!r}")
            if bad_files:
                return Verdict(
                    WA,
                    f"测试「{label}」的输出对了，但**写出来的文件不对**（第 {idx}/{len(cases)} 组）：\n"
                    + "\n".join(f"· {b}" for b in bad_files),
                    stdout=res.stdout,
                    stderr=res.stderr,
                )

            last = res
        finally:
            shutil.rmtree(workdir, ignore_errors=True)

    if not compare:
        return Verdict(
            RUN,
            "运行完成。这个实验不判对错 —— 看你自己的输出就行。",
            stdout=last.stdout,
            stderr=last.stderr,
            time_ms=last.time_ms,
            peak_mem_mb=last.peak_mem_mb,
        )
    return Verdict(
        AC,
        f"全部 {len(cases)} 组测试通过 ✅",
        stdout=last.stdout,
        time_ms=last.time_ms,
        peak_mem_mb=last.peak_mem_mb,
    )


def _config_parse(text: str, target_file: str):
    """按文件名/格式解析配置文件。返回 (doc, error)。"""
    name = (target_file or "").lower()
    if name.endswith((".yaml", ".yml")):
        fmt = "yaml"
    elif name.endswith(".json"):
        fmt = "json"
    elif name.endswith(".ini") or name.endswith(".conf") or name.endswith(".service"):
        fmt = "ini"
    elif name.endswith("dockerfile") or name == "dockerfile" or name.endswith(".dockerfile"):
        fmt = "dockerfile"
    else:
        fmt = "text"

    if fmt == "yaml":
        yaml = _load_vendored_yaml()
        if yaml is None:
            return None, "判题环境缺少 YAML 解析器（judge/vendor/yaml），请重新准备判题环境"
        try:
            return yaml.safe_load(text), None
        except Exception as e:  # noqa: BLE001 —— 解析器的异常类型很多，统一报 CE
            return None, f"YAML 解析失败：{e}"
    if fmt == "json":
        try:
            return json.loads(text), None
        except json.JSONDecodeError as e:
            return None, f"JSON 解析失败：第 {e.lineno} 行第 {e.colno} 列 {e.msg}"
    if fmt == "ini":
        import configparser
        cp = configparser.ConfigParser()
        try:
            cp.read_string(text)
        except configparser.Error as e:
            return None, f"INI 解析失败：{e}"
        return {s: dict(cp.items(s)) for s in cp.sections()}, None
    if fmt == "dockerfile":
        # Dockerfile 不是结构化格式：解析成「指令序列 + 出现的行」，
        # 断言用 `line_regex` / `instruction` 两种判据（见 _judge_config）。
        ins = []
        for i, ln in enumerate(text.split("\n"), 1):
            s = ln.strip()
            if not s or s.startswith("#"):
                continue
            parts = s.split(None, 1)
            ins.append({"n": i, "op": parts[0].upper(),
                        "arg": (parts[1] if len(parts) > 1 else "")})
        return {"instructions": ins, "text": text}, None
    return {"text": text}, None


def _load_vendored_yaml():
    """加载 vendor 进仓库的纯 Python PyYAML（MIT，见 judge/vendor/NOTICE.md）。

    为什么 vendor 而不是让运行时去装：内置嵌入式 Python **没有 pip、没有
    site-packages**，装第三方包要动运行时的下载清单与自检；而纯 Python 的
    PyYAML 只有 ~200 KB、17 个文件，直接随 judge/ 走最省事（也不会随环境漂移）。
    """
    try:
        import vendor.yaml as yaml  # type: ignore
        return yaml
    except Exception:
        pass
    here = os.path.dirname(os.path.abspath(__file__))
    vdir = os.path.join(here, "vendor")
    if os.path.isdir(vdir) and vdir not in sys.path:
        sys.path.insert(0, vdir)
    try:
        import yaml  # type: ignore
        return yaml
    except Exception:
        return None


def _norm_scalar(v) -> str:
    """把配置里的标量归一成可比较的字符串。

    YAML 会把 `true` 解析成 Python `True`、`3` 解析成整数 3 —— 而断言是手写的
    `"true"` / `"3"`。所以比较前统一：布尔转小写 true/false，其余去空白转字符串，
    并整体忽略大小写（`256M` 与 `256m` 在 compose 里语义不同，但这类差异交给
    `equals` 的调用方用更精确的判据表达；这里只解决"类型不同导致的假失败"）。
    """
    if isinstance(v, bool):
        return "true" if v else "false"
    return str(v).strip().lower()


def _dig(doc, path: str):
    """按 `a.b.0.c` 取值；取不到返回 (False, None)。`*` 表示"任意一项"。"""
    cur = doc
    for part in [p for p in (path or "").split(".") if p != ""]:
        if part == "*":
            return True, cur           # 由调用方决定怎么用（只支持"存在任意一项"）
        if isinstance(cur, dict):
            if part not in cur:
                return False, None
            cur = cur[part]
        elif isinstance(cur, list):
            if not part.isdigit() or int(part) >= len(cur):
                return False, None
            cur = cur[int(part)]
        else:
            return False, None
    return True, cur


def _check_assert(doc, text: str, a: dict) -> tuple[bool, str]:
    """判一条断言。返回 (通过?, 说明)。断言类型见 docs/开发者说明.md 的「config 题怎么写」。"""
    kind = (a.get("kind") or "").strip().lower()

    # Dockerfile 专用：按指令/正则判（它没有结构化路径）
    if kind == "instruction":
        op = (a.get("op") or "").upper()
        ins = (doc or {}).get("instructions") or []
        hit = [x for x in ins if x["op"] == op and (not a.get("arg_regex") or
               re.search(a["arg_regex"], x["arg"], re.I))]
        return (bool(hit) if a.get("exists", True) else not hit), \
               (f"指令 {op}{'（arg 匹配 ' + a['arg_regex'] + '）' if a.get('arg_regex') else ''}"
                f"{'存在' if hit else '不存在'}")
    if kind == "line_regex":
        m = re.search(a.get("regex", ""), text or "", re.I | re.M)
        return bool(m) == bool(a.get("exists", True)), \
               f"文本{'匹配' if m else '不匹配'} /{a.get('regex','')}/"

    path = a.get("path", "")
    ok, val = _dig(doc, path)

    if kind == "not_exists":
        # 断言「这个键必须不出现」（例如「日志走默认驱动」= 不写 logging 段）
        return (val is None), (f"{path} 不存在 ✅" if val is None
                               else f"{path} 存在（值 {val!r}），但断言要求它不存在")
    if kind == "exists":
        want = bool(a.get("exists", True))
        return ok == want, f"{path} {'存在' if ok else '不存在'}"
    if not ok:
        return False, f"{path} 不存在（断言要求它存在）"
    if kind == "equals":
        # YAML 里 `replicas: 3` 是整数，而断言常写成字符串 "3" —— 两边统一按去空白字符串比较，
        # 否则会出现「配置写对了、判据说类型不匹配」的假失败（实测：LX3-7 的 deploy.replicas）。
        _eq = _norm_scalar(val) == _norm_scalar(a.get("value"))
        return _eq, f"{path} = {val!r}（期望 {a.get('value')!r}）"
    if kind == "contains":
        want = a.get("value")
        good = (want in val) if isinstance(val, (list, str)) else False
        return good, f"{path} {'包含' if good else '不包含'} {want!r}（实际 {val!r}）"
    if kind == "regex":
        # ⚠️ 配置里的值常常是**列表**（健康检查的 test、ports、env、command…）。
        # 实测踩过（LX3-3）：`services.web.healthcheck.test` 是
        # `["CMD","curl","-f","http://localhost/health"]`，只支持字符串的 regex
        # 会判"不匹配"，看起来像学生的配置写错了。列表语义：**任一项匹配即通过**。
        if isinstance(val, list):
            hit = next((x for x in val if isinstance(x, str) and re.search(a.get("regex", ""), x)), None)
            return bool(hit), (f"{path} 列表里有「{hit}」" if hit
                               else f"{path} 列表 {val!r} 没有一项匹配 /{a.get('regex','')}/")
        good = isinstance(val, str) and bool(re.search(a.get("regex", ""), val))
        return good, f"{path} = {val!r} {'匹配' if good else '不匹配'} /{a.get('regex','')}/"
    if kind == "not_regex":
        if isinstance(val, list):
            bad_item = next((x for x in val if isinstance(x, str) and re.search(a.get("regex", ""), x)), None)
            return (bad_item is None), (f"{path} 列表{'里没有' if bad_item is None else '含'}"
                                        f" /{a.get('regex','')}/ 的项")
        good = isinstance(val, str) and not re.search(a.get("regex", ""), val)
        return good, f"{path} = {val!r} {'不含' if good else '含有'} /{a.get('regex','')}/"
    if kind == "min_len":
        good = hasattr(val, "__len__") and len(val) >= int(a.get("value", 0))
        return good, f"{path} 长度 {len(val) if hasattr(val,'__len__') else '?'} ≥ {a.get('value')}"
    if kind in ("min_value", "max_value"):
        # 数值比较：`replicas >= 2`、`timeout_ms <= 5000`、`version >= 2` 这类断言
        # 在真实配置题里很常见（AG2 的提示模板要判 version ≥ 2 时发现的缺口）。
        # ⚠️ 只认数字：字符串数字（"3"）也接受，非数字要**明确报错**而不是静默不通过。
        try:
            num = float(val)
        except (TypeError, ValueError):
            return False, f"{path} = {val!r} 不是数字，无法做 {kind} 比较"
        want = float(a.get("value", 0))
        good = num >= want if kind == "min_value" else num <= want
        op = "≥" if kind == "min_value" else "≤"
        return good, f"{path} = {num:g} {op} {want:g}"
    return False, f"未知的断言类型 kind={kind!r}"


def _judge_config(*, code: str, asserts: list, target_file: str) -> Verdict:
    """配置文件题：解析 + 按断言集判。**判题强度：静态语义判定（不真跑）。**

    为什么不是"逐字节比对"：配置题的正确答案不止一种（键顺序、引号、锚点都能变），
    而且我们要能给出**分项反馈**（"这几条做到了、那两条没做到"）——
    这对 Docker/K8s 这种"配置有十几个考点"的题是刚需。

    为什么不是"真跑 docker compose up"：软件不往系统里装 Docker/WSL（用户定的路线），
    所以这一层只能判**配置语义**。题面上必须写明这一点，不能让用户以为服务真起来了。
    """
    if not (code or "").strip():
        return Verdict(WA, "还没有写内容。")
    if not asserts:
        return Verdict(SE, "这道 config 题没有配置 asserts（断言集）")

    # 文件名决定按什么语法解析。**认不出来就报 SE，不要静默按纯文本判** ——
    # 静默的后果是断言全部"路径不存在"，学生看到的是"我写对了却全错"，
    # 而这种题最容易让人怀疑自己（实测踩过：漏传 target_file 时判成 0/3 分）。
    ext_ok = (".yaml", ".yml", ".json", ".ini", ".conf", ".service", ".dockerfile")
    low = (target_file or "").lower()
    if not low or not (low.endswith(ext_ok) or low == "dockerfile"):
        return Verdict(
            SE,
            f"这道 config 题没有声明可识别的文件名（收到 {target_file!r}）——"
            "判题要靠文件名决定按 YAML/JSON/INI/Dockerfile 哪种语法解析。"
            "内容里给这道题加一个 `file` 字段即可。",
        )

    doc, err = _config_parse(code, target_file)
    if err:
        return Verdict(
            CE,
            f"{err}\n（配置题的解析失败相当于编程题的编译失败：先修结构，再谈对不对。）",
            compile_output=err,
        )

    total = sum(int(a.get("weight", 1)) for a in asserts) or 1
    got = 0
    lines = []
    failed = []
    for i, a in enumerate(asserts, 1):
        w = int(a.get("weight", 1))
        ok, detail = _check_assert(doc, code, a)
        if ok:
            got += w
        else:
            failed.append(a)
        lines.append(f"{'✅' if ok else '❌'} {a.get('desc', f'断言 {i}')}"
                     f"（{detail}；{w} 分）")

    score = f"{got}/{total} 分"
    # ⚠️ 措辞要和题型相符：这段原来写死「不启动容器 / 在 Docker 环境里验证」，
    # 而 config 模式现在也用来判**工具定义、请求体**这类非容器配置（AG1 就是）。
    # 说「容器」会让学员以为题目出错了。
    head = (f"**配置语义检查：{score}**\n\n"
            "> 本题只判**内容本身**（静态语义：解析后逐条核对，不真跑）—— 语义写对了算通过；"
            "需要真跑的部分（服务起没起来、容器跑没跑通）请在真实环境里自己验证。\n")
    body = "\n".join(lines)
    if not failed:
        return Verdict(AC, f"{head}\n{body}\n\n全部断言通过 ✅", stdout=code)
    return Verdict(
        WA,
        f"{head}\n{body}\n\n还差 {total - got} 分：先看上面 ❌ 的那几条。",
        stdout=code,
    )


def _judge_diagnose(*, code: str, asserts: list) -> Verdict:
    """排障诊断题：用户按固定格式写判断，按**要点**逐条给分。

    ## 为什么用"结构化作答"而不是模拟终端

    真实排障考的是三件事：**看哪条证据 → 得出什么结论 → 怎么处置**。
    模拟一个能交互的终端当然更像真的，但那需要一整套会话状态机与前端交互；
    而这三件事本身用一页日志 + 一段结构化回答就能考到 —— 而且判分确定、可复现、
    不需要任何额外环境（不装 Docker/K8s、不联网）。

    ## 作答格式（题面里会给）

    ```text
    CAUSE: 连接池耗尽
    EVIDENCE: 12
    FIX: 调大连接池上限，并给获取连接加超时
    ```

    - `CAUSE`：根因（一到两句）
    - `EVIDENCE`：**你据以判断的那条证据**（通常给日志行号或关键片段）——
      这是"路径"的可判形式：它记录了你是从哪条线索得出结论的
    - `FIX`：处置动作

    ⚠️ 已知限制（题面与 gaps 里都写明）：这是**按要点给分的结构化诊断**，
    不是"真的让你在终端里一步步排查"。后者的价值主要在交互手感，
    要做得先有会话状态机 + 前端步骤 UI，属于后续工作。
    """
    if not (code or "").strip():
        return Verdict(WA, "还没有写你的判断。按题面要求写 CAUSE / EVIDENCE / FIX 三行。")
    if not asserts:
        return Verdict(SE, "这道诊断题没有配置 asserts（要点清单）")

    # 解析：允许用户写成 `CAUSE: xxx` 或 `因果：xxx`；大小写与全角冒号都容忍
    keys = {"cause": ("cause", "原因", "根因", "因果"),
            "evidence": ("evidence", "证据", "依据"),
            "fix": ("fix", "处置", "修复", "处理")}
    sections = {k: "" for k in keys}
    for raw in (code or "").split("\n"):
        line = raw.strip().lstrip("-*# ").replace("：", ":")
        if ":" not in line:
            continue
        name, _, value = line.partition(":")
        name = name.strip().lower()
        for field, aliases in keys.items():
            if name in aliases:
                sections[field] = value.strip()
                break

    missing = [f.upper() for f in ("cause", "evidence", "fix") if not sections[f]]
    if missing:
        return Verdict(
            WA,
            f"还缺 {'、'.join(missing)} —— 诊断要写全三行：\n"
            "```text\nCAUSE: 根因（一到两句）\nEVIDENCE: 你据以判断的证据（行号或关键片段）\n"
            "FIX: 处置动作\n```",
        )

    total = sum(int(a.get("weight", 1)) for a in asserts) or 1
    got = 0
    lines = []
    for i, a in enumerate(asserts, 1):
        w = int(a.get("weight", 1))
        field = (a.get("field") or "cause").strip().lower()
        text = sections.get(field, "")
        ok, detail = _check_answer_assert(text, a)
        if ok:
            got += w
        lines.append(f"{'✅' if ok else '❌'} {a.get('desc', f'要点 {i}')}"
                     f"（{detail}；{w} 分）")

    head = (f"**诊断要点：{got}/{total} 分**\n\n"
            "> 本题判的是**你的判断与依据**（不是让你真在终端里排查）。\n")
    body = "\n".join(lines)
    if got == total:
        return Verdict(AC, f"{head}\n{body}\n\n要点齐全 ✅", stdout=code)
    return Verdict(WA, f"{head}\n{body}\n\n还差 {total - got} 分：看上面 ❌ 的几条。",
                   stdout=code, short_hint="对着日志再读一遍，想想哪条证据能排除其它可能")


def _check_answer_assert(text: str, a: dict) -> tuple[bool, str]:
    """判一条"作答要点"。支持 regex / contains / equals / any_of 四种判据。

    `any_of` 是给"同义说法"用的：处置动作常常有多种正确写法
    （「加超时」或「调大上限」都对），硬写一个正则会把合理的答案判错。
    """
    kind = (a.get("kind") or "regex").strip().lower()
    show = (text or "")[:40] or "（空）"
    if kind == "regex":
        ok = bool(re.search(a.get("regex", ""), text or "", re.I))
        return ok, f"{'匹配' if ok else '不匹配'} /{a.get('regex','')}/，你写的是「{show}」"
    if kind == "contains":
        ok = (a.get("value") or "") in (text or "")
        return ok, f"{'含' if ok else '不含'}「{a.get('value')}」，你写的是「{show}」"
    if kind == "equals":
        ok = (text or "").strip() == str(a.get("value", "")).strip()
        return ok, f"{'等于' if ok else '不等于'}「{a.get('value')}」，你写的是「{show}」"
    if kind == "any_of":
        vals = a.get("values") or []
        hit = next((v for v in vals if v in (text or "")), None)
        return bool(hit), (f"命中「{hit}」" if hit else f"没命中任何一项（{vals}），你写的是「{show}」")
    return False, f"未知的判据 kind={kind!r}"


def find_llvm_objdump(toolchain: Toolchain | None = None) -> str | None:
    """找 llvm-objdump：优先跟 clang 同一个 bin 目录（随判题环境装的 LLVM 里就有）。"""
    cands = []
    cxx = getattr(toolchain, "cxx", None) if toolchain else None
    if cxx:
        cands.append(os.path.join(os.path.dirname(cxx), "llvm-objdump.exe"))
        cands.append(os.path.join(os.path.dirname(cxx), "llvm-objdump"))
    rt = (os.environ.get("BAZHOU_RUNTIME_DIR") or "").strip()
    if rt:
        cands.append(os.path.join(rt, "llvm", "bin", "llvm-objdump.exe"))
    here = os.path.dirname(os.path.abspath(__file__))
    cands.append(os.path.join(os.path.dirname(here), "runtime", "llvm", "bin", "llvm-objdump.exe"))
    for p in cands:
        if p and os.path.isfile(p):
            return p
    return shutil.which("llvm-objdump")


def _judge_embed(
    *,
    code: str,
    files: dict,
    tests: list,
    asserts: list,
    expected: str,
    time_limit_ms: int,
    mem_limit_mb: int,
    toolchain: Toolchain,
    workdir_root: str | None,
) -> Verdict:
    """嵌入式题：**目标平台真交叉编译 + objdump 断言 + 主机侧寄存器仿真真跑**。

    ## 为什么是这三层，而不是"仿真一个开发板"

    本软件不可能给用户准备开发板，也不该假装能"烧进去跑一遍"。但嵌入式代码的
    正确性有三层**可以真判**的证据：

    ① **能不能为目标编译**：`--target=armv6m-none-eabi -ffreestanding` 是真实的交叉编译
       （实测可用），编译不过就是编译不过；
    ② **生成的指令对不对**：`llvm-objdump` 能看出有没有除法（Cortex-M0 **没有硬件除法器**，
       写 `/` 会引入 `__aeabi_idiv` 软件除法，几十个周期）、有没有浮点、代码多大；
    ③ **逻辑对不对**：题面给一份**假外设头**（寄存器映射成数组、事件用函数注入），
       把同一份代码在主机上编译运行，判"寄存器写序列" —— 这才是嵌入式的行为判据。

    ⚠️ 诚实边界（题面要写）：不烧板子、不测真实时序、不测中断延迟。这三层证明的是
    「代码能为目标平台编译、生成的指令符合约束、寄存器操作序列正确」，不是「在真板子上跑通了」。

    判据分工：`tests` 判主机侧仿真的 stdout；`asserts` 判源码与汇编层面的约束
    （`source_not_match` / `source_match` / `no_symbol` / `has_symbol` / `code_size_max`）。
    """
    if not (code or "").strip():
        return Verdict(WA, "还没有写代码。题目要求你写能在目标平台上编译并正确操作寄存器的代码。")

    cxx = getattr(toolchain, "cxx", None)
    if not cxx:
        return Verdict(SE, "判题环境里没有 C++ 编译器，无法做交叉编译（见「设置 → 判题环境」）")

    workdir = tempfile.mkdtemp(prefix="embedjudge_", dir=workdir_root)
    try:
        for rel, content in (files or {}).items():
            p = os.path.join(workdir, rel.replace("/", os.sep))
            parent = os.path.dirname(p)
            if parent:
                os.makedirs(parent, exist_ok=True)
            with open(p, "w", encoding="utf-8", newline="\n") as fh:
                fh.write(content)
        with open(os.path.join(workdir, "main.cpp"), "w", encoding="utf-8", newline="\n") as fh:
            fh.write(code)

        env = make_env(toolchain)
        target = os.environ.get("BAZHOU_EMBED_TARGET", "armv6m-none-eabi")

        # ── ① 交叉编译（只编译，不链接：裸机链接需要链接脚本与启动文件，那是另一课）──
        obj = os.path.join(workdir, "main.o")
        try:
            cross = subprocess.run(
                [cxx, f"--target={target}", "-std=c++20", "-ffreestanding", "-fno-exceptions",
                 "-fno-rtti", "-Os", "-Wall", "-I", workdir, "-c", "main.cpp", "-o", "main.o"],
                cwd=workdir, capture_output=True, text=True, encoding="utf-8",
                errors="replace", timeout=120, env=env,
            )
        except OSError as e:
            # 编译器路径坏了（文件不在/没权限）：这是判题环境的问题，不是用户代码的问题 ——
            # 必须报 SE。少了这一支，判题进程会直接抛 FileNotFoundError 崩掉（自检抓到的真 bug）。
            return Verdict(SE, f"调用编译器失败（{cxx}）：{e}。请重新准备判题环境。")
        if cross.returncode != 0:
            return Verdict(
                CE,
                f"交叉编译失败（目标 {target}）—— 这段代码在目标平台上编译不过。",
                compile_output=(cross.stdout or "") + (cross.stderr or ""),
            )
        cross_warnings = (cross.stderr or "").strip()

        # ── ② objdump 断言（源码层面 + 汇编层面）──
        disasm = ""
        if any(a.get("kind") in ("no_symbol", "has_symbol", "code_size_max") for a in asserts):
            od = find_llvm_objdump(toolchain)
            if not od:
                return Verdict(
                    SE,
                    "判题环境里没有 llvm-objdump，无法检查生成的指令（见「设置 → 判题环境」）",
                )
            # ⚠️ 必须带 `-r`（重定位）：目标文件里外部调用的**符号名只在重定位表**里，
            # `-d` 的文本里只有 `bl 0x12 <_Z4mainv+0x12>` —— 少了 `-r`，
            # 「有没有软件除法」这条断言会永远看不到符号名（实测踩过）。
            d = subprocess.run([od, "-dr", obj], capture_output=True, text=True,
                               encoding="utf-8", errors="replace", timeout=60, env=env)
            disasm = d.stdout or ""
            if not disasm.strip():
                return Verdict(SE, f"objdump 没有输出：{(d.stderr or '')[:160]}")

        # 源码类断言判的是"剥掉字符串与注释之后的代码"（见 _strip_cpp_strings_and_comments）
        code_bare = _strip_cpp_strings_and_comments(code)

        report: list[str] = []
        got = 0
        total = 0
        for i, a in enumerate(asserts, 1):
            w = int(a.get("weight", 1))
            total += w
            kind = (a.get("kind") or "").strip().lower()
            rx = a.get("regex", "")
            # `"raw": true` → 匹配**原文**（有些判据本来就要匹配字符串字面量，
            # 例如 `extern "C" void irq_handler` 里的 "C"）。
            src_for_assert = code if a.get("raw") else code_bare
            if kind == "source_not_match":
                hit = re.search(rx, src_for_assert, re.I)
                okk, detail = (hit is None), ("源码里没有出现" if hit is None
                                              else f"源码里出现了 {hit.group(0)!r}")
            elif kind == "source_match":
                hit = re.search(rx, src_for_assert, re.I)
                okk, detail = bool(hit), ("源码里出现了" if hit else "源码里没找到")
            elif kind == "no_symbol":
                hit = re.search(rx, disasm, re.I)
                okk, detail = (hit is None), ("汇编里没有该符号" if hit is None
                                              else f"汇编里出现了 {hit.group(0)!r}")
            elif kind == "has_symbol":
                hit = re.search(rx, disasm, re.I)
                okk, detail = bool(hit), ("汇编里出现了" if hit else "汇编里没找到")
            elif kind == "code_size_max":
                size = os.path.getsize(obj)
                okk, detail = size <= int(a.get("value", 0)), f"目标文件 {size} 字节"
            else:
                okk, detail = False, f"未知判据 kind={kind!r}"
            if okk:
                got += w
            report.append(f"{'✅' if okk else '❌'} {a.get('desc', f'约束 {i}')}（{detail}；{w} 分）")

        # ── ③ 主机侧寄存器仿真（真跑；题面给的假外设头把寄存器映射成数组）──
        host_out = ""
        if tests or expected:
            host_exe = os.path.join(workdir, "host.exe")
            host = subprocess.run(
                # `-DBAZHOU_HOST_SIM`：题面给的假外设头靠这个宏区分「目标平台」与「主机仿真」
                # （目标平台没有标准库，只有主机才能用 <cstdio> 打印寄存器序列）。
                [cxx, "-std=c++20", "-O0", "-g", "-Wall", "-DBAZHOU_HOST_SIM", "-I", workdir,
                 "main.cpp", "-o", host_exe],
                cwd=workdir, capture_output=True, text=True, encoding="utf-8",
                errors="replace", timeout=120, env=env,
            )
            if host.returncode != 0:
                return Verdict(
                    CE,
                    "主机侧仿真编译失败 —— 题面给的假外设头（sim 头文件）用法不对，"
                    "或代码里有只能为目标平台编译的东西。",
                    compile_output=(host.stdout or "") + (host.stderr or ""),
                )
            limits = Limits(
                wall_time_ms=max(time_limit_ms + 2000, 3000),
                cpu_time_ms=time_limit_ms,
                memory_mb=mem_limit_mb,
                output_bytes=256 * 1024,
                max_processes=8,
            )
            cases = tests or [{"name": "本题", "stdin": "", "expected": expected}]
            for idx, case in enumerate(cases, 1):
                res = sandbox_run([host_exe], limits=limits,
                                  stdin_data=case.get("stdin", "") or "",
                                  cwd=workdir, env=env)
                label = case.get("name") or f"第 {idx} 组"
                if res.error:
                    return Verdict(SE, res.error)
                if res.killed_reason in ("wall", "cpu"):
                    return Verdict(TLE, f"超时（限制 {time_limit_ms} ms）：寄存器仿真里出现了"
                                        "不会结束的循环（常见于「等标志位」写成了死等）。",
                                   stdout=res.stdout)
                if res.killed_reason == "output":
                    return Verdict(OLE, "输出内容过多，可能是死循环在疯狂打印", stdout=res.stdout)
                if res.exit_code != 0:
                    return Verdict(RE, f"仿真运行崩溃（退出码 {res.exit_code:#x}）。"
                                       "常见原因：越界访问寄存器数组、空指针、除以零。",
                                   stdout=res.stdout, stderr=res.stderr,
                                   crash_hint=res.crash_hint)
                want = _normalize_shell_output(case.get("expected", "") or "")
                gotout = _normalize_shell_output(res.stdout or "")
                if gotout != want:
                    return Verdict(
                        WA,
                        f"**寄存器写序列不对**（测试「{label}」第 {idx}/{len(cases)} 组）。\n"
                        "下面「程序的真实输出」是仿真实测到的寄存器操作序列。",
                        stdout=res.stdout,
                        stderr=res.stderr,
                        actual_output=case.get("expected", ""),
                        compile_output=cross_warnings,
                    )
                host_out = res.stdout

        head = (f"**目标平台编译：通过**（`--target={target}`）；"
                f"**寄存器仿真：通过**\n")
        body = "\n".join(report) if report else "（本题没有额外的汇编/源码约束）"
        if total and got != total:
            return Verdict(
                WA,
                f"{head}\n{body}\n\n行为对了，但**约束还差 {total - got} 分**：看上面 ❌ 的几条。",
                stdout=host_out, compile_output=cross_warnings,
            )
        return Verdict(
            AC,
            f"{head}\n{body}\n\n全部通过 ✅",
            stdout=host_out, time_ms=0, compile_output=cross_warnings,
        )
    except subprocess.TimeoutExpired:
        return Verdict(SE, "编译器/objdump 执行超时（判题环境异常）")
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


def _strip_cpp_strings_and_comments(src: str) -> str:
    """把源码里的字符串字面量与注释替换成空格（保留换行），供 `source_*` 断言使用。

    ⚠️ 为什么必须剥（实测踩过）：判「源码里没有对值做除法/取模」时，
    `SIM_PRINT("MS %u\\n", ms)` 里的**格式符 `%u`** 被正则当成了取模运算 →
    写对了的参考解被判 WA。字符串与注释里的内容不是代码，判源码级约束前必须先剥掉。

    只处理最常见形态（`"..."`、`'...'`、`//`、`/* */`，含反斜杠转义）；不追求词法完备 ——
    它的用途是「别被字符串骗」，不是做编译器。
    """
    out = []
    i, n = 0, len(src)
    while i < n:
        ch = src[i]
        if ch == "/" and i + 1 < n and src[i + 1] == "/":          # 行注释
            while i < n and src[i] != "\n":
                out.append(" ")
                i += 1
        elif ch == "/" and i + 1 < n and src[i + 1] == "*":        # 块注释
            while i < n and not (src[i] == "*" and i + 1 < n and src[i + 1] == "/"):
                out.append("\n" if src[i] == "\n" else " ")
                i += 1
            out.append("  ")
            i = min(i + 2, n)
        elif ch in "\"'":                                          # 字符串/字符字面量
            quote = ch
            out.append(" ")
            i += 1
            while i < n and src[i] != quote:
                if src[i] == "\\" and i + 1 < n:
                    out.append(" ")
                    i += 1
                out.append("\n" if src[i] == "\n" else " ")
                i += 1
            out.append(" ")
            i = min(i + 1, n)
        else:
            out.append(ch)
            i += 1
    return "".join(out)


def judge_case(
    *,
    mode: str,
    code: str = "",          # 选择题不需要代码，所以给默认值
    expected: str = "",
    stdin_data: str = "",
    answer: str = "",
    choices: list | None = None,
    tests: list | None = None,
    float_tol: float | None = None,
    time_limit_ms: int = DEFAULT_TIME_LIMIT_MS,
    mem_limit_mb: int = DEFAULT_MEM_LIMIT_MB,
    toolchain: Toolchain | None = None,
    workdir_root: str | None = None,
    # ── 新方向专用（`shell` / `config`）────────────────────────────────
    files: dict | None = None,      # shell：题面给定的初始文件树 {相对路径: 内容}
    asserts: list | None = None,    # config：断言集（见 _judge_config）
    target_file: str = "",          # config：用户写的是哪个文件（决定按什么语法解析）
) -> Verdict:
    """判一道题。参数与章节 JSON 里的 exercises[] 字段一一对应。"""
    # ⚠️ 工具链缺失要**返回 SE**，不能把异常抛出去。
    # 实测（2026-09 修 CI）：`detect()` 找不到编译器时是 `raise RuntimeError`，
    # 于是任何"忘了传 toolchain"的调用方（检查器、探针、CI 门禁）都会**直接崩** ——
    # 而那不是内容问题，是环境问题。判题器在任何环境下都该给出可解释的结果。
    try:
        toolchain = toolchain or detect()
    except Exception as exc:  # noqa: BLE001
        return Verdict(SE, f"判题环境里没有可用的 C++ 编译器：{exc}")
    mode = normalize_mode(mode)

    if mode not in ALL_MODES:
        return Verdict(SE, f"未知的题型 mode：{mode!r}")

    # 选择题不编译代码，直接比对选项下标
    if mode == "multiple_choice":
        return _judge_multiple_choice(expected=expected, answer=answer, choices=choices or [])

    # shell：在本机真跑 busybox sh（新方向，见 SHELL_MODES 的说明）
    # shell_run：同一套执行，只是**不比对**（实验的"运行看看"）
    if mode in SHELL_MODES or mode in SHELL_RUN_MODES:
        return _judge_shell(
            code=code,
            files=files or {},
            tests=tests or [],
            expected=expected,
            stdin_data=stdin_data,
            time_limit_ms=time_limit_ms,
            mem_limit_mb=mem_limit_mb,
            toolchain=toolchain,
            workdir_root=workdir_root,
            compare=mode in SHELL_MODES,
        )

    # config：解析配置文件 + 按断言集判（不真跑容器）
    if mode in CONFIG_MODES:
        return _judge_config(
            code=code,
            asserts=asserts or [],
            target_file=target_file,
        )

    # diagnose：结构化诊断（现象 → 证据 → 处置），按要点给分
    if mode in DIAGNOSE_MODES:
        return _judge_diagnose(code=code, asserts=asserts or [])

    # python：在本机真跑用户写的 Python（Agent / Infra 的代码题，见 PYTHON_MODES 说明）
    # python_run：同一套执行，只是**不比对**（实验的"运行看看"）
    if mode in PYTHON_MODES or mode in PYTHON_RUN_MODES:
        return _judge_python(
            code=code,
            files=files or {},
            tests=tests or [],
            expected=expected,
            stdin_data=stdin_data,
            time_limit_ms=time_limit_ms,
            mem_limit_mb=mem_limit_mb,
            toolchain=toolchain,
            workdir_root=workdir_root,
            compare=mode in PYTHON_MODES,
        )

    # embed：交叉编译 + objdump 断言 + 主机侧寄存器仿真
    if mode in EMBED_MODES:
        return _judge_embed(
            code=code,
            files=files or {},
            tests=tests or [],
            asserts=asserts or [],
            expected=expected,
            time_limit_ms=time_limit_ms,
            mem_limit_mb=mem_limit_mb,
            toolchain=toolchain,
            workdir_root=workdir_root,
        )

    # predictOutput 不走"用户改代码"那条路，单独处理完就返回
    if mode == "predict_output":
        return _judge_predict_output(
            code=code,
            expected=expected,
            answer=answer,
            stdin_data=stdin_data,
            time_limit_ms=time_limit_ms,
            toolchain=toolchain,
            workdir_root=workdir_root,
        )

    workdir = tempfile.mkdtemp(prefix="cppjudge_", dir=workdir_root)
    try:
        with open(os.path.join(workdir, "main.cpp"), "w", encoding="utf-8", newline="\n") as fh:
            fh.write(code)

        build = _compile(toolchain, workdir, mode)

        # ---------------------------------------------------------------
        # mode: compile_fail —— 目标就是"让它编译不过"
        # ---------------------------------------------------------------
        if mode == "compile_fail":
            if build.error:
                return Verdict(SE, build.error, compile_output=build.compile_output)
            if not build.ok:
                return Verdict(
                    AC,
                    "编译如期失败，static_assert 生效 ✅",
                    compile_output=build.compile_output,
                )
            return Verdict(
                WA,
                "这题的预期是编译失败，但你的代码编译通过了。"
                "检查一下 static_assert 的条件是不是写反了，或者被绕过了。",
                compile_output=build.compile_output,
            )

        # ---------------------------------------------------------------
        # 其余 mode 需要编译通过
        # ---------------------------------------------------------------
        if build.error:
            return Verdict(SE, build.error, compile_output=build.compile_output)
        if not build.ok:
            return Verdict(CE, "编译失败，看下方报错定位", compile_output=build.compile_output)

        # ---------------------------------------------------------------
        # 运行
        # ---------------------------------------------------------------
        run_limits = Limits(
            wall_time_ms=max(time_limit_ms + 2000, 3000),  # 墙钟比 CPU 限制宽松，避免误判
            cpu_time_ms=time_limit_ms,
            # 坑（交接文档踩坑记录第 1 条）：ASan 会预留巨量虚拟地址空间，
            # 设内存上限会导致误报。所以 sanitizer 模式下必须放开内存限制。
            memory_mb=0 if mode == "asan" else mem_limit_mb,
            output_bytes=256 * 1024,
            max_processes=8,
        )
        env = make_env(toolchain)
        if mode == "asan":
            env.update(asan_env_options(toolchain))

        # 必须给可执行文件的**绝对路径**。Windows 的 CreateProcess 只在 PATH 里
        # 找映像名，不会去 cwd 里找——传 "main.exe" 会直接报 WinError 2。
        # （clang 编译阶段没这个问题，因为相对路径是程序自己按 cwd 解析的。）
        exe_path = os.path.join(workdir, "main.exe")

        def run_once(stdin_str: str):
            """把程序跑一次。

            返回 (res, err)。err 非 None 表示这是环境/资源类问题，
            调用方应直接把 err 当判定结果返回——它和"用户代码对不对"无关。
            抽成闭包是为了让多测试能复用同一次编译产物。
            """
            res = sandbox_run(
                [exe_path],
                limits=run_limits,
                stdin_data=stdin_str,
                cwd=workdir,
                env=env,
            )
            if res.error:
                return res, Verdict(SE, res.error)

            # DLL 缺失要单独识别：这不是用户代码的问题，是判题环境没配好。
            # 典型场景就是 ASan 运行时 DLL 不在 PATH 里。
            if (res.exit_code & 0xFFFFFFFF) == STATUS_DLL_NOT_FOUND:
                return res, Verdict(
                    SE,
                    "程序启动失败：缺少运行时 DLL。"
                    "如果是 ASan 题，请确认 clang_rt.asan_dynamic-x86_64.dll 已加入 PATH"
                    "（见 judge/toolchain.py 的 _find_asan_dir）。",
                    stderr=res.stderr,
                )

            # 资源类判定优先于崩溃判定（和沙箱层的优先级保持一致）
            if res.killed_reason == "memory":
                return res, Verdict(
                    MLE, f"内存超出限制（峰值 {res.peak_mem_mb} MB）", stdout=res.stdout
                )
            if res.killed_reason in ("wall", "cpu"):
                return res, Verdict(
                    TLE,
                    f"超时（限制 {time_limit_ms} ms，实际 CPU {res.cpu_ms} ms）。"
                    "常见原因：死循环、缺少递归终止条件。",
                    stdout=res.stdout,
                )
            if res.killed_reason == "output":
                return res, Verdict(
                    OLE, "输出内容过多，可能是死循环在疯狂打印", stdout=res.stdout
                )
            return res, None

        # ---------------------------------------------------------------
        # mode: run —— 只运行、不判定（开放式实验用）
        #
        # 报告 3F / 第 10 节 X2：任务是"改成你自己的内容"这类开放实验时，
        # 没有唯一正确答案，但仍然要"真的跑起来给用户看输出"。
        # 所以这里只负责编译 + 运行，编译错误和运行崩溃照常反馈（那是有用的），
        # 但**不比对任何 expected**，也不给 AC/WA。
        # ---------------------------------------------------------------
        if mode == "run":
            res, err = run_once(stdin_data)
            if err:
                return err
            if res.exit_code != 0:
                return Verdict(
                    RE,
                    f"程序异常退出（退出码 {res.exit_code:#x}）。"
                    "这个实验不判对错，但程序没能正常跑完，先按报错检查代码。",
                    stdout=res.stdout,
                    stderr=res.stderr,
                    crash_hint=res.crash_hint,
                    time_ms=res.time_ms,
                )
            return Verdict(
                RUN,
                "运行完成。这个实验不判对错 —— 看你自己的输出就行。",
                stdout=res.stdout,
                stderr=res.stderr,
                time_ms=res.time_ms,
                peak_mem_mb=res.peak_mem_mb,
            )

        # ---------------------------------------------------------------
        # 多测试（tests 数组）—— Level Challenge / 算法训练场用
        #
        # 报告 7.5 要求每题带边界测试；只比对单个 expected 的话，
        # 错误解很容易蒙混过关。这里编译**一次**，按 tests 逐个跑。
        # 任何一组不过就立刻返回，并指出是第几组。
        # ---------------------------------------------------------------
        if tests and mode in MULTI_TEST_MODES:
            total = len(tests)
            for i, t in enumerate(tests, 1):
                name = (t.get("name") or f"第 {i} 组") if isinstance(t, dict) else f"第 {i} 组"
                tin = (t.get("stdin") or "") if isinstance(t, dict) else ""
                texp = (t.get("expected") or "") if isinstance(t, dict) else ""

                res, err = run_once(tin)
                if err:
                    return err
                if res.exit_code != 0:
                    return Verdict(
                        RE,
                        f"测试「{name}」程序异常退出（退出码 {res.exit_code:#x}）",
                        stdout=res.stdout,
                        stderr=res.stderr,
                        crash_hint=res.crash_hint,
                    )
                ok, hint = compare_output(res.stdout, texp, float_tol)
                if not ok:
                    return Verdict(
                        WA,
                        f"测试「{name}」未通过（第 {i}/{total} 组）：{hint}",
                        stdout=res.stdout,
                        stderr=res.stderr,
                    )
            return Verdict(
                AC,
                f"全部 {total} 组测试通过 ✅（含边界用例）",
                stdout=res.stdout,
            )

        # ---------------------------------------------------------------
        # 单测试（没有 tests 数组时按原来的走）
        # ---------------------------------------------------------------
        res, err = run_once(stdin_data)
        if err:
            return err

        # ---------------------------------------------------------------
        # mode: asan —— 判据是"退出码 + sanitizer 报告"，不是输出内容
        # ---------------------------------------------------------------
        if mode == "asan":
            if _looks_like_sanitizer(res.stderr):
                report = _extract_sanitizer_report(res.stderr)
                return Verdict(
                    WA,
                    "检测到未定义行为 / 内存错误，看下方 sanitizer 报告定位 ✅",
                    stdout=res.stdout,
                    stderr=res.stderr,
                    sanitizer_report=report,
                    time_ms=res.time_ms,
                    peak_mem_mb=res.peak_mem_mb,
                )
            if res.exit_code != 0:
                return Verdict(
                    RE,
                    f"程序异常退出（退出码 {res.exit_code:#x}）",
                    stdout=res.stdout,
                    stderr=res.stderr,
                    crash_hint=res.crash_hint,
                    time_ms=res.time_ms,
                    peak_mem_mb=res.peak_mem_mb,
                )
            # sanitizer 干净。如果题目还要求输出，就再比一次输出
            if expected:
                ok, hint = compare_output(res.stdout, expected, float_tol)
                if not ok:
                    return Verdict(
                        WA,
                        f"没有内存问题，但输出不对：{hint}",
                        stdout=res.stdout,
                        stderr=res.stderr,
                        time_ms=res.time_ms,
                        peak_mem_mb=res.peak_mem_mb,
                    )
            return Verdict(
                AC,
                "ASan / UBSan 无任何报警，且输出正确 ✅",
                stdout=res.stdout,
                stderr=res.stderr,
                time_ms=res.time_ms,
                peak_mem_mb=res.peak_mem_mb,
            )

        # ---------------------------------------------------------------
        # mode: output —— 看退出码，再比输出
        # ---------------------------------------------------------------
        if res.exit_code != 0:
            return Verdict(
                RE,
                f"程序异常退出（退出码 {res.exit_code:#x}）",
                stdout=res.stdout,
                stderr=res.stderr,
                crash_hint=res.crash_hint,
                time_ms=res.time_ms,
                peak_mem_mb=res.peak_mem_mb,
            )

        ok, hint = compare_output(res.stdout, expected, float_tol)
        if ok:
            return Verdict(
                AC,
                "输出正确 ✅",
                stdout=res.stdout,
                time_ms=res.time_ms,
                peak_mem_mb=res.peak_mem_mb,
            )
        return Verdict(
            WA,
            f"输出不正确：{hint}",
            stdout=res.stdout,
            stderr=res.stderr,
            time_ms=res.time_ms,
            peak_mem_mb=res.peak_mem_mb,
        )

    finally:
        shutil.rmtree(workdir, ignore_errors=True)


def _extract_sanitizer_report(stderr: str) -> str:
    """从 stderr 里裁出 sanitizer 报告主体，去掉无关噪音。"""
    lines = stderr.split("\n")
    start = 0
    for i, ln in enumerate(lines):
        if "Sanitizer" in ln or "runtime error:" in ln:
            start = max(0, i - 1)
            break
    return "\n".join(lines[start:]).strip()
