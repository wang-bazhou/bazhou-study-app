"""判题引擎：三种题型 mode 的判定逻辑。

===============================================================================
和上一轮（Linux 沙箱）的关系
===============================================================================
判定逻辑**原样复用**上一轮已验证的成果，三种 mode 的行为保持不变：

    mode           判定方式                             适用知识点
    --------------+------------------------------------+---------------------------
    output        stdout 比对（支持浮点容差）           输出预测、算法、语法
    compile_fail  期望编译失败（static_assert 类题）     类型推导、SFINAE、traits
    asan          ASan+UBSan 无报警（可叠加输出校验）     UB、越界、悬垂指针、找 bug

唯一改动的是"怎么限制进程"这一层——换成了 sandbox_win.py 的 Job Object。
判定码集合不变：AC / WA / CE / RE / TLE / MLE / OLE，另加 SE（沙箱自身出错，
不是用户代码的问题）。

===============================================================================
设计原则 1 的落地（交接文档第六条）
===============================================================================
UB 类知识点**不能**用"运行结果比对"判题。所以 asan 模式的判据是进程退出码
和 sanitizer 报告，而不是输出内容——目标是"能识别并消除 UB"，不是"跑出正确结果"。
"""

from __future__ import annotations

import os
import shutil
import tempfile
from dataclasses import dataclass, field

try:
    from sandbox_win import Limits, RunResult
except ImportError:  # Linux/macOS：判定原语（常量/Verdict/compare_output）可用，
    # 但本模块的「编译运行」路径依赖 Windows 沙箱——Linux 平台的执行请走
    # judge/linux_judge.py（ExecutionBackend）。见 docs/移植说明.md 与 L10 架构文档。
    Limits = None  # type: ignore[assignment]
    RunResult = None  # type: ignore[assignment]
try:
    from sandbox_win import run as sandbox_run
except ImportError:  # Linux/macOS：见上方软导入说明
    sandbox_run = None  # type: ignore[assignment]
from toolchain import Toolchain, asan_env_options, detect, make_env

# =============================================================================
# 判定码
# =============================================================================

AC = "AC"  # Accepted        通过
WA = "WA"  # Wrong Answer    答案错误（含检测到 UB）
CE = "CE"  # Compile Error   编译失败
RE = "RE"  # Runtime Error   运行时崩溃
TLE = "TLE"  # Time Limit     超时
MLE = "MLE"  # Memory Limit   超内存
OLE = "OLE"  # Output Limit   输出超量
SE = "SE"  # System Error    判题系统自身出错（编译器缺失、DLL 缺失等）

# RUN 不是"通过"，而是"跑起来了，但这题不判对错"。
# 用于**开放式实验**（报告 3F / 第 10 节 X2）：任务是"改成你自己的内容"这类
# 没有唯一答案的实验，只要求能跑起来并让用户看到输出。前端不该给它打 AC 徽章。
RUN = "RUN"  # Ran OK          已运行（不判定）

VERDICT_TEXT = {
    RUN: "已运行",
    AC: "通过",
    WA: "答案错误",
    CE: "编译失败",
    RE: "运行时错误",
    TLE: "超时",
    MLE: "超出内存限制",
    OLE: "输出超出限制",
    SE: "判题系统错误",
}

DEFAULT_TIME_LIMIT_MS = 2000
DEFAULT_MEM_LIMIT_MB = 512

# 章节 JSON 里的 mode 用驼峰（compileFail / predictOutput），
# Python 惯例用下划线（compile_fail / predict_output）。
# 这里做一次归一化，两种写法都接受——内容产出方（沙箱会话）不用迁就判题引擎。
MODE_ALIASES = {
    "compile_fail": "compile_fail",
    "compilefail": "compile_fail",
    "compile-fail": "compile_fail",
    "output": "output",
    "asan": "asan",
    "sanitizer": "asan",
    "predict_output": "predict_output",
    "predictoutput": "predict_output",
    "predict-output": "predict_output",
    "multiple_choice": "multiple_choice",
    "multiplechoice": "multiple_choice",
    "multiple-choice": "multiple_choice",
    "choice": "multiple_choice",
    # 只运行不判定：给开放式实验用
    "run": "run",
    "runonly": "run",
    "run_only": "run",
}

# 需要用户改动代码才能通过的题型（内容健康检查里的"baseline must fail"针对它们）
CODE_EDITING_MODES = {"output", "compile_fail", "asan"}

# 用户在答案框里填预测输出的题型
PREDICT_MODES = {"predict_output"}

# 选择题：用户在选项里挑一个，后端比对正确下标
CHOICE_MODES = {"multiple_choice"}

# 只运行不判定的题型（开放式实验）
RUN_MODES = {"run"}

# 全部合法题型
ALL_MODES = CODE_EDITING_MODES | PREDICT_MODES | CHOICE_MODES | RUN_MODES

# 支持多测试（tests 数组）的题型 —— 这些是"编译运行后比对输出"的题
MULTI_TEST_MODES = {"output", "asan"}


def normalize_mode(mode: str) -> str:
    """把各种写法的 mode 归一化成标准形式。"""
    key = (mode or "").strip().lower()
    return MODE_ALIASES.get(key, key)



# 编译阶段给得宽松些：模板递归、头文件多的时候会比运行慢得多
COMPILE_WALL_MS = 30000
COMPILE_MEM_MB = 2048
COMPILE_OUTPUT_BYTES = 128 * 1024

# 0xC0000135 = STATUS_DLL_NOT_FOUND
STATUS_DLL_NOT_FOUND = 0xC0000135


@dataclass
class Verdict:
    """一次判题的结果，直接序列化成 JSON 返回给前端。"""

    verdict: str = SE
    message: str = ""
    stdout: str = ""
    stderr: str = ""
    compile_output: str = ""
    time_ms: int = 0
    peak_mem_mb: float = 0.0
    crash_hint: str = ""
    sanitizer_report: str = ""
    # predictOutput 用：程序真实输出。只在提交之后才回传，用来讲解
    actual_output: str = ""
    # predictOutput 用：判错时的一句话提示，不泄露完整答案
    short_hint: str = ""
    # multipleChoice 用：正确选项下标。**只在提交之后**回传，供前端高亮
    correct_index: int | None = None

    def to_dict(self) -> dict:
        return {
            "verdict": self.verdict,
            "verdictText": VERDICT_TEXT.get(self.verdict, self.verdict),
            "message": self.message,
            "stdout": self.stdout,
            "stderr": self.stderr,
            "compileOutput": self.compile_output,
            "timeMs": self.time_ms,
            "peakMemMb": self.peak_mem_mb,
            "crashHint": self.crash_hint,
            "sanitizerReport": self.sanitizer_report,
            "actualOutput": self.actual_output,
            "shortHint": self.short_hint,
            "correctIndex": self.correct_index,
        }


# =============================================================================
# 输出比对
# =============================================================================


def _normalize(text: str) -> str:
    """规范化输出：去掉每行行尾空白和结尾多余空行。

    判题器不应该因为"多了一个换行"或"行尾多了个空格"判 WA——那不是知识点。
    """
    lines = [ln.rstrip() for ln in text.replace("\r\n", "\n").split("\n")]
    while lines and lines[-1] == "":
        lines.pop()
    while lines and lines[0] == "":
        lines.pop(0)
    return "\n".join(lines)


def compare_output(actual: str, expected: str, float_tol: float | None) -> tuple[bool, str]:
    """比对输出。返回 (是否通过, 差异说明)。

    有 float_tol 时按数值逐 token 比较（浮点题专用）；否则按规范化后的文本比较。
    """
    a = _normalize(actual)
    e = _normalize(expected)

    if float_tol is None:
        if a == e:
            return True, ""
        return False, _diff_hint(a, e)

    a_tokens = a.split()
    e_tokens = e.split()
    if len(a_tokens) != len(e_tokens):
        return False, f"输出项数不一致：期望 {len(e_tokens)} 个，实际 {len(a_tokens)} 个"

    for i, (av, ev) in enumerate(zip(a_tokens, e_tokens)):
        try:
            af, ef = float(av), float(ev)
        except ValueError:
            if av != ev:
                return False, f"第 {i + 1} 项不一致：期望 {ev!r}，实际 {av!r}"
            continue
        if abs(af - ef) > float_tol:
            return False, f"第 {i + 1} 项超出容差：期望 {ev}，实际 {av}（容差 {float_tol}）"
    return True, ""


def _diff_hint(actual: str, expected: str) -> str:
    """给出"第一行哪里不一样"的人话提示，比甩两份全文好用得多。"""
    a_lines = actual.split("\n")
    e_lines = expected.split("\n")
    for i in range(max(len(a_lines), len(e_lines))):
        av = a_lines[i] if i < len(a_lines) else "<无这一行>"
        ev = e_lines[i] if i < len(e_lines) else "<无这一行>"
        if av != ev:
            return f"第 {i + 1} 行不一致：期望 {ev!r}，实际 {av!r}"
    return "输出与期望不一致"


def _predict_hint(answer: str, expected: str) -> str:
    """predictOutput 判错时的一句话提示。

    刻意**不给出期望值**——直接告诉答案，"先押注再看结果"的教学价值就没了。
    只提示"哪一行不对 / 行数不对"，把思考留给用户。
    """
    a = _normalize(answer).split("\n")
    e = _normalize(expected).split("\n")
    if len(a) != len(e):
        return f"输出的行数不对（你写了 {len(a)} 行）。再数一下程序一共打印了几行。"
    for i, (x, y) in enumerate(zip(a, e)):
        if x != y:
            return f"第 {i + 1} 行不对。再算算这一行实际会打印什么。"
    return "内容不完全一致，注意行尾空格和末尾空行。"


def _judge_predict_output(
    *,
    code: str,
    expected: str,
    answer: str,
    stdin_data: str = "",
    time_limit_ms: int = DEFAULT_TIME_LIMIT_MS,
    toolchain: Toolchain,
    workdir_root: str | None = None,
) -> Verdict:
    """predictOutput 模式：代码只读，用户在答案框里填自己预测的 stdout。

    和 output 模式的本质区别：
      output          = 用户改代码，让程序输出正确答案
      predictOutput   = 代码不能改，用户必须**先押注**再提交

    为什么必须拆开（这是之前踩的坑）：
      把"预测输出"题做成 output 模式时，初始代码本身就能跑出 expected，
      用户点一下判题直接 AC，什么都没学到。

    判据要点：
      - 空答案必须判 WA（不做就等于没做）
      - 提交前绝不把 expected 送到前端（前端压根拿不到这个字段）
      - 判错只给位置提示，不泄露答案
      - 判对后才回传真实输出 + 题解
      - 顺带跑一遍示例程序，验证题目内容本身没错
    """
    if not (answer or "").strip():
        return Verdict(WA, "请先在答案框里填写你预测的输出，再提交。")

    workdir = tempfile.mkdtemp(prefix="cpppredict_", dir=workdir_root)
    real_stdout = ""
    try:
        with open(os.path.join(workdir, "main.cpp"), "w", encoding="utf-8", newline="\n") as fh:
            fh.write(code)

        build = _compile(toolchain, workdir, "output")
        if build.error:
            return Verdict(SE, build.error)
        if not build.ok:
            # 示例代码自己编译不过 —— 内容错误，不是用户的错
            return Verdict(
                SE,
                "这道题的示例代码本身编译失败（内容错误，请修章节 JSON）：\n" + build.compile_output[:600],
            )

        exe = os.path.join(workdir, "main.exe")
        res = sandbox_run(
            [exe],
            limits=Limits(
                wall_time_ms=max(time_limit_ms + 2000, 3000),
                cpu_time_ms=time_limit_ms,
                memory_mb=DEFAULT_MEM_LIMIT_MB,
                output_bytes=64 * 1024,
                max_processes=8,
            ),
            stdin_data=stdin_data,
            cwd=workdir,
            env=make_env(toolchain),
        )
        if res.error:
            return Verdict(SE, res.error)
        real_stdout = res.stdout
    finally:
        shutil.rmtree(workdir, ignore_errors=True)

    # 内容自检：示例程序的真实输出必须等于 expected，否则题目本身是错的
    content_ok, _ = compare_output(real_stdout, expected, None)
    if not content_ok:
        return Verdict(
            SE,
            "这道题的示例代码实际输出与 expected 不一致（内容错误）。\n"
            f"真实输出：{_normalize(real_stdout)!r}\n"
            f"expected：{_normalize(expected)!r}",
            actual_output=real_stdout,
        )

    ok, _ = compare_output(answer, expected, None)
    if ok:
        return Verdict(AC, "预测正确 ✅", actual_output=real_stdout)
    return Verdict(
        WA,
        "预测不对。" + _predict_hint(answer, expected),
        short_hint=_predict_hint(answer, expected),
    )


def exercise_items(ch: dict) -> list:
    """一个章节文件里的「题目」：普通章节取 exercises[]，挑战文件取 challenges[]。

    所有工具都从这里取，别各自判断 —— 否则漏一处就会出现
    「挑战文件检查通过但什么都没查」这种假绿灯。
    """
    ex = ch.get("exercises")
    if isinstance(ex, list) and ex:
        return ex
    chs = ch.get("challenges")
    if isinstance(chs, list):
        return chs
    return []


def correct_choice_index(choices: list | None) -> int | None:
    """选择题：找出 `correct: true` 的下标。找不到返回 None。"""
    for i, c in enumerate(choices or []):
        if isinstance(c, dict) and c.get("correct"):
            return i
    return None


def judge_exercise(ex: dict, *, answer: str = "", toolchain: Toolchain | None = None) -> Verdict:
    """**从章节 JSON 里的一道题直接判题——所有调用方都走这里。**

    存在的理由：有些折算规则只有一处应该知道。比如「选择题的 expected
    是正确选项下标、而章节 JSON 里根本不写 expected」——
    如果 Rust、健康检查、结构校验各写一遍，早晚会有一处漏掉，
    表现就是"明明是好题却被报 SE"。
    """
    mode = normalize_mode(ex.get("mode", ""))
    choices = ex.get("choices") or []
    expected = ex.get("expected", "") or ""

    if mode == "multiple_choice":
        ci = correct_choice_index(choices)
        expected = "" if ci is None else str(ci)

    return judge_case(
        mode=mode,
        code=ex.get("code", "") or "",
        expected=expected,
        stdin_data=ex.get("stdin", "") or "",
        answer=answer,
        choices=choices,
        tests=ex.get("tests") or [],
        float_tol=ex.get("float_tol", ex.get("floatTol")),
        toolchain=toolchain,
    )


def _judge_multiple_choice(*, expected: str, answer: str, choices: list) -> Verdict:
    """选择题（含判断题）。

    `expected` 是**正确选项的下标**——Rust 侧读 `choices[].correct` 折算好后传进来，
    这样判题就退化成一次整数比较，不用把整个选项数组的逻辑搬到这里。

    反馈设计（对应报告 6.4「每个错误选项为什么错」）：
      - 答错时只回传"你选的那一项为什么错"（`shortHint`），
        不告诉用户正确答案是哪个 —— 让ta自己再想一次
      - 提交后才通过 `correctIndex` 回传正确下标，前端据此高亮
    """
    ans = (answer or "").strip()
    if not ans:
        return Verdict(WA, "请先选择一个选项再提交。")

    try:
        chosen = int(ans)
    except ValueError:
        return Verdict(SE, f"选择题的答案应该是选项下标，收到 {ans!r}")

    if not choices:
        return Verdict(SE, "这道选择题没有配置 choices 数组")
    if not 0 <= chosen < len(choices):
        return Verdict(SE, f"选项下标越界：{chosen}（共 {len(choices)} 项）")

    try:
        correct = int((expected or "").strip())
    except ValueError:
        return Verdict(SE, "这道选择题没有配置正确选项（choices 里缺少 correct: true）")

    if chosen == correct:
        return Verdict(AC, "选对了", correct_index=correct)

    why = ""
    c = choices[chosen]
    if isinstance(c, dict):
        why = (c.get("why") or "").strip()

    v = Verdict(WA, "选错了。再看看这一项为什么不对。", correct_index=correct)
    v.short_hint = why
    return v


def _looks_like_sanitizer(stderr: str) -> bool:
    """判断这段 stderr 是不是 sanitizer 报告。"""
    markers = (
        "AddressSanitizer",
        "runtime error:",
        "UndefinedBehaviorSanitizer",
        "SUMMARY: ",
        "LeakSanitizer",
    )
    return any(m in stderr for m in markers)


# =============================================================================
# 编译
# =============================================================================


@dataclass
class BuildResult:
    ok: bool
    compile_output: str = ""
    error: str = ""


def _build_command(tc: Toolchain, source: str, exe: str, mode: str) -> list[str]:
    cmd = [tc.cxx, "-std=c++20", "-O0", "-g", source, "-o", exe]
    if mode == "asan":
        # -fno-omit-frame-pointer 让 ASan 能打出可读的调用栈
        cmd += ["-fsanitize=address,undefined", "-fno-omit-frame-pointer"]
    # 编译期就暴露 UB/越界：这些警告不进判定，但会随 compile_output 展示，
    # 帮用户理解"为什么这段代码在编译期就有问题"
    cmd += ["-Wall", "-Wextra"]
    return cmd


def _compile(tc: Toolchain, workdir: str, mode: str) -> BuildResult:
    source = os.path.join(workdir, "main.cpp")
    exe = os.path.join(workdir, "main.exe")

    cmd = _build_command(tc, "main.cpp", "main.exe", mode)
    limits = Limits(
        wall_time_ms=COMPILE_WALL_MS,
        cpu_time_ms=COMPILE_WALL_MS,
        memory_mb=COMPILE_MEM_MB,
        output_bytes=COMPILE_OUTPUT_BYTES,
        max_processes=16,
    )
    env = make_env(tc)
    if mode == "asan":
        env.update(asan_env_options(tc))

    res = sandbox_run(cmd, limits=limits, cwd=workdir, env=env)

    if res.error:
        return BuildResult(False, error=res.error)

    output = (res.stdout + res.stderr).strip()

    if res.killed_reason in ("wall", "cpu"):
        return BuildResult(False, compile_output=output, error="编译超时（可能是模板无限递归展开）")
    if res.killed_reason == "memory":
        return BuildResult(False, compile_output=output, error="编译器内存耗尽")
    if res.killed_reason == "output":
        return BuildResult(False, compile_output=output, error="编译输出过多（模板报错爆炸）")

    if res.exit_code != 0 or not os.path.isfile(exe):
        return BuildResult(False, compile_output=output)

    return BuildResult(True, compile_output=output)


# =============================================================================
# 主入口
# =============================================================================


def judge_case(
    *,
    mode: str,
    code: str = "",          # 选择题不需要代码，所以给默认值
    expected: str = "",
    stdin_data: str = "",
    answer: str = "",
    choices: list | None = None,
    tests: list | None = None,
    float_tol: float | None = None,
    time_limit_ms: int = DEFAULT_TIME_LIMIT_MS,
    mem_limit_mb: int = DEFAULT_MEM_LIMIT_MB,
    toolchain: Toolchain | None = None,
    workdir_root: str | None = None,
) -> Verdict:
    """判一道题。参数与章节 JSON 里的 exercises[] 字段一一对应。"""
    toolchain = toolchain or detect()
    mode = normalize_mode(mode)

    if mode not in ALL_MODES:
        return Verdict(SE, f"未知的题型 mode：{mode!r}")

    # 选择题不编译代码，直接比对选项下标
    if mode == "multiple_choice":
        return _judge_multiple_choice(expected=expected, answer=answer, choices=choices or [])

    # predictOutput 不走"用户改代码"那条路，单独处理完就返回
    if mode == "predict_output":
        return _judge_predict_output(
            code=code,
            expected=expected,
            answer=answer,
            stdin_data=stdin_data,
            time_limit_ms=time_limit_ms,
            toolchain=toolchain,
            workdir_root=workdir_root,
        )

    workdir = tempfile.mkdtemp(prefix="cppjudge_", dir=workdir_root)
    try:
        with open(os.path.join(workdir, "main.cpp"), "w", encoding="utf-8", newline="\n") as fh:
            fh.write(code)

        build = _compile(toolchain, workdir, mode)

        # ---------------------------------------------------------------
        # mode: compile_fail —— 目标就是"让它编译不过"
        # ---------------------------------------------------------------
        if mode == "compile_fail":
            if build.error:
                return Verdict(SE, build.error, compile_output=build.compile_output)
            if not build.ok:
                return Verdict(
                    AC,
                    "编译如期失败，static_assert 生效 ✅",
                    compile_output=build.compile_output,
                )
            return Verdict(
                WA,
                "这题的预期是编译失败，但你的代码编译通过了。"
                "检查一下 static_assert 的条件是不是写反了，或者被绕过了。",
                compile_output=build.compile_output,
            )

        # ---------------------------------------------------------------
        # 其余 mode 需要编译通过
        # ---------------------------------------------------------------
        if build.error:
            return Verdict(SE, build.error, compile_output=build.compile_output)
        if not build.ok:
            return Verdict(CE, "编译失败，看下方报错定位", compile_output=build.compile_output)

        # ---------------------------------------------------------------
        # 运行
        # ---------------------------------------------------------------
        run_limits = Limits(
            wall_time_ms=max(time_limit_ms + 2000, 3000),  # 墙钟比 CPU 限制宽松，避免误判
            cpu_time_ms=time_limit_ms,
            # 坑（交接文档踩坑记录第 1 条）：ASan 会预留巨量虚拟地址空间，
            # 设内存上限会导致误报。所以 sanitizer 模式下必须放开内存限制。
            memory_mb=0 if mode == "asan" else mem_limit_mb,
            output_bytes=256 * 1024,
            max_processes=8,
        )
        env = make_env(toolchain)
        if mode == "asan":
            env.update(asan_env_options(toolchain))

        # 必须给可执行文件的**绝对路径**。Windows 的 CreateProcess 只在 PATH 里
        # 找映像名，不会去 cwd 里找——传 "main.exe" 会直接报 WinError 2。
        # （clang 编译阶段没这个问题，因为相对路径是程序自己按 cwd 解析的。）
        exe_path = os.path.join(workdir, "main.exe")

        def run_once(stdin_str: str):
            """把程序跑一次。

            返回 (res, err)。err 非 None 表示这是环境/资源类问题，
            调用方应直接把 err 当判定结果返回——它和"用户代码对不对"无关。
            抽成闭包是为了让多测试能复用同一次编译产物。
            """
            res = sandbox_run(
                [exe_path],
                limits=run_limits,
                stdin_data=stdin_str,
                cwd=workdir,
                env=env,
            )
            if res.error:
                return res, Verdict(SE, res.error)

            # DLL 缺失要单独识别：这不是用户代码的问题，是判题环境没配好。
            # 典型场景就是 ASan 运行时 DLL 不在 PATH 里。
            if (res.exit_code & 0xFFFFFFFF) == STATUS_DLL_NOT_FOUND:
                return res, Verdict(
                    SE,
                    "程序启动失败：缺少运行时 DLL。"
                    "如果是 ASan 题，请确认 clang_rt.asan_dynamic-x86_64.dll 已加入 PATH"
                    "（见 judge/toolchain.py 的 _find_asan_dir）。",
                    stderr=res.stderr,
                )

            # 资源类判定优先于崩溃判定（和沙箱层的优先级保持一致）
            if res.killed_reason == "memory":
                return res, Verdict(
                    MLE, f"内存超出限制（峰值 {res.peak_mem_mb} MB）", stdout=res.stdout
                )
            if res.killed_reason in ("wall", "cpu"):
                return res, Verdict(
                    TLE,
                    f"超时（限制 {time_limit_ms} ms，实际 CPU {res.cpu_ms} ms）。"
                    "常见原因：死循环、缺少递归终止条件。",
                    stdout=res.stdout,
                )
            if res.killed_reason == "output":
                return res, Verdict(
                    OLE, "输出内容过多，可能是死循环在疯狂打印", stdout=res.stdout
                )
            return res, None

        # ---------------------------------------------------------------
        # mode: run —— 只运行、不判定（开放式实验用）
        #
        # 报告 3F / 第 10 节 X2：任务是"改成你自己的内容"这类开放实验时，
        # 没有唯一正确答案，但仍然要"真的跑起来给用户看输出"。
        # 所以这里只负责编译 + 运行，编译错误和运行崩溃照常反馈（那是有用的），
        # 但**不比对任何 expected**，也不给 AC/WA。
        # ---------------------------------------------------------------
        if mode == "run":
            res, err = run_once(stdin_data)
            if err:
                return err
            if res.exit_code != 0:
                return Verdict(
                    RE,
                    f"程序异常退出（退出码 {res.exit_code:#x}）。"
                    "这个实验不判对错，但程序没能正常跑完，先按报错检查代码。",
                    stdout=res.stdout,
                    stderr=res.stderr,
                    crash_hint=res.crash_hint,
                    time_ms=res.time_ms,
                )
            return Verdict(
                RUN,
                "运行完成。这个实验不判对错 —— 看你自己的输出就行。",
                stdout=res.stdout,
                stderr=res.stderr,
                time_ms=res.time_ms,
                peak_mem_mb=res.peak_mem_mb,
            )

        # ---------------------------------------------------------------
        # 多测试（tests 数组）—— Level Challenge / 算法训练场用
        #
        # 报告 7.5 要求每题带边界测试；只比对单个 expected 的话，
        # 错误解很容易蒙混过关。这里编译**一次**，按 tests 逐个跑。
        # 任何一组不过就立刻返回，并指出是第几组。
        # ---------------------------------------------------------------
        if tests and mode in MULTI_TEST_MODES:
            total = len(tests)
            for i, t in enumerate(tests, 1):
                name = (t.get("name") or f"第 {i} 组") if isinstance(t, dict) else f"第 {i} 组"
                tin = (t.get("stdin") or "") if isinstance(t, dict) else ""
                texp = (t.get("expected") or "") if isinstance(t, dict) else ""

                res, err = run_once(tin)
                if err:
                    return err
                if res.exit_code != 0:
                    return Verdict(
                        RE,
                        f"测试「{name}」程序异常退出（退出码 {res.exit_code:#x}）",
                        stdout=res.stdout,
                        stderr=res.stderr,
                        crash_hint=res.crash_hint,
                    )
                ok, hint = compare_output(res.stdout, texp, float_tol)
                if not ok:
                    return Verdict(
                        WA,
                        f"测试「{name}」未通过（第 {i}/{total} 组）：{hint}",
                        stdout=res.stdout,
                        stderr=res.stderr,
                    )
            return Verdict(
                AC,
                f"全部 {total} 组测试通过 ✅（含边界用例）",
                stdout=res.stdout,
            )

        # ---------------------------------------------------------------
        # 单测试（没有 tests 数组时按原来的走）
        # ---------------------------------------------------------------
        res, err = run_once(stdin_data)
        if err:
            return err

        # ---------------------------------------------------------------
        # mode: asan —— 判据是"退出码 + sanitizer 报告"，不是输出内容
        # ---------------------------------------------------------------
        if mode == "asan":
            if _looks_like_sanitizer(res.stderr):
                report = _extract_sanitizer_report(res.stderr)
                return Verdict(
                    WA,
                    "检测到未定义行为 / 内存错误，看下方 sanitizer 报告定位 ✅",
                    stdout=res.stdout,
                    stderr=res.stderr,
                    sanitizer_report=report,
                    time_ms=res.time_ms,
                    peak_mem_mb=res.peak_mem_mb,
                )
            if res.exit_code != 0:
                return Verdict(
                    RE,
                    f"程序异常退出（退出码 {res.exit_code:#x}）",
                    stdout=res.stdout,
                    stderr=res.stderr,
                    crash_hint=res.crash_hint,
                    time_ms=res.time_ms,
                    peak_mem_mb=res.peak_mem_mb,
                )
            # sanitizer 干净。如果题目还要求输出，就再比一次输出
            if expected:
                ok, hint = compare_output(res.stdout, expected, float_tol)
                if not ok:
                    return Verdict(
                        WA,
                        f"没有内存问题，但输出不对：{hint}",
                        stdout=res.stdout,
                        stderr=res.stderr,
                        time_ms=res.time_ms,
                        peak_mem_mb=res.peak_mem_mb,
                    )
            return Verdict(
                AC,
                "ASan / UBSan 无任何报警，且输出正确 ✅",
                stdout=res.stdout,
                stderr=res.stderr,
                time_ms=res.time_ms,
                peak_mem_mb=res.peak_mem_mb,
            )

        # ---------------------------------------------------------------
        # mode: output —— 看退出码，再比输出
        # ---------------------------------------------------------------
        if res.exit_code != 0:
            return Verdict(
                RE,
                f"程序异常退出（退出码 {res.exit_code:#x}）",
                stdout=res.stdout,
                stderr=res.stderr,
                crash_hint=res.crash_hint,
                time_ms=res.time_ms,
                peak_mem_mb=res.peak_mem_mb,
            )

        ok, hint = compare_output(res.stdout, expected, float_tol)
        if ok:
            return Verdict(
                AC,
                "输出正确 ✅",
                stdout=res.stdout,
                time_ms=res.time_ms,
                peak_mem_mb=res.peak_mem_mb,
            )
        return Verdict(
            WA,
            f"输出不正确：{hint}",
            stdout=res.stdout,
            stderr=res.stderr,
            time_ms=res.time_ms,
            peak_mem_mb=res.peak_mem_mb,
        )

    finally:
        shutil.rmtree(workdir, ignore_errors=True)


def _extract_sanitizer_report(stderr: str) -> str:
    """从 stderr 里裁出 sanitizer 报告主体，去掉无关噪音。"""
    lines = stderr.split("\n")
    start = 0
    for i, ln in enumerate(lines):
        if "Sanitizer" in ln or "runtime error:" in ln:
            start = max(0, i - 1)
            break
    return "\n".join(lines[start:]).strip()
