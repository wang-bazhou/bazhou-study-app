"""Windows 进程沙箱：用 Job Object 替代 POSIX 的 rlimit。

===============================================================================
为什么需要这个文件
===============================================================================
上一轮在 Linux 沙箱里验证的判题引擎，靠 POSIX 的这几个机制限制用户代码：

    POSIX 机制                本文件里的 Windows 对应实现
    -------------------------+------------------------------------------------
    RLIMIT_CPU (SIGXCPU)     -> JOB_OBJECT_LIMIT_PROCESS_TIME
    RLIMIT_AS                -> JOB_OBJECT_LIMIT_PROCESS_MEMORY
    RLIMIT_FSIZE             -> stdout/stderr 重定向到临时文件 + 主循环轮询大小
    RLIMIT_NPROC (防 fork 炸弹)-> JOB_OBJECT_LIMIT_ACTIVE_PROCESS
    墙钟超时（双保险）        -> 主循环计时 + TerminateJobObject
    独立临时目录 + 自动清理    -> tempfile.mkdtemp + 退出时 shutil.rmtree

Windows 内核根本没有 rlimit / SIGXCPU，所以这一层**必须重写**，不能照搬。
判定逻辑（AC/WA/CE 那套）在 engine.py 里原样保留，本文件只管"怎么安全地跑一个进程"。

===============================================================================
一个重要的坑：TLE / MLE / RE 的区分方式变了
===============================================================================
在 Linux 上，CPU 超时会给进程发 SIGXCPU（信号 24），判题器捕获到这个信号就能
确定地判 TLE。Windows 的 Job Object 没有等价物——进程时间/内存超限时，内核
直接把它杀掉，不留下"我是被哪个限制杀死的"这种明确标记。

所以本文件的做法是"事后对账"，按下面的优先级判定（killed_reason）：

    1. 主循环发现墙钟超时            -> "wall"    -> TLE
    2. 峰值内存 >= 内存上限           -> "memory"  -> MLE
    3. CPU 时间 >= CPU 上限           -> "cpu"     -> TLE
    4. 输出字节数 >= 输出上限         -> "output"  -> OLE
    5. 以上都不是但退出码非 0         -> 交给调用方判 RE

这个优先级保证：一个同时超内存又超时间的程序，会被判成我们更关心的那个原因。
"""

from __future__ import annotations

import ctypes
import os
import shutil
import subprocess
import sys
import tempfile
import time
from ctypes import wintypes
from dataclasses import dataclass, field

# =============================================================================
# Win32 API 声明
# =============================================================================

if sys.platform != "win32":
    raise ImportError(
        "sandbox_win 只能在 Windows 上运行。"
        "（Linux/macOS 请使用 posix 版沙箱，见 docs/移植说明.md）"
    )

_kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

# Job Object 限制标志位
JOB_OBJECT_LIMIT_PROCESS_TIME = 0x00000002
JOB_OBJECT_LIMIT_JOB_TIME = 0x00000004
JOB_OBJECT_LIMIT_ACTIVE_PROCESS = 0x00000008
JOB_OBJECT_LIMIT_PROCESS_MEMORY = 0x00000100
JOB_OBJECT_LIMIT_JOB_MEMORY = 0x00000200
JOB_OBJECT_LIMIT_DIE_ON_UNHANDLED_EXCEPTION = 0x00000400
JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x00002000

# JobObjectInformationClass 枚举中我们用到的两个
JobObjectBasicAccountingInformation = 1
JobObjectExtendedLimitInformation = 9

# 退出码常量
STILL_ACTIVE = 259

# 进程创建标志
CREATE_NO_WINDOW = 0x08000000
CREATE_NEW_PROCESS_GROUP = 0x00000200
CREATE_SUSPENDED = 0x00000004


class IO_COUNTERS(ctypes.Structure):
    _fields_ = [
        ("ReadOperationCount", ctypes.c_ulonglong),
        ("WriteOperationCount", ctypes.c_ulonglong),
        ("OtherOperationCount", ctypes.c_ulonglong),
        ("ReadTransferCount", ctypes.c_ulonglong),
        ("WriteTransferCount", ctypes.c_ulonglong),
        ("OtherTransferCount", ctypes.c_ulonglong),
    ]


class JOBOBJECT_BASIC_LIMIT_INFORMATION(ctypes.Structure):
    _fields_ = [
        # 时间单位是 100 纳秒
        ("PerProcessUserTimeLimit", ctypes.c_longlong),
        ("PerJobUserTimeLimit", ctypes.c_longlong),
        ("LimitFlags", wintypes.DWORD),
        ("MinimumWorkingSetSize", ctypes.c_size_t),
        ("MaximumWorkingSetSize", ctypes.c_size_t),
        ("ActiveProcessLimit", wintypes.DWORD),
        ("Affinity", ctypes.c_size_t),
        ("PriorityClass", wintypes.DWORD),
        ("SchedulingClass", wintypes.DWORD),
    ]


class JOBOBJECT_EXTENDED_LIMIT_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("BasicLimitInformation", JOBOBJECT_BASIC_LIMIT_INFORMATION),
        ("IoInfo", IO_COUNTERS),
        ("ProcessMemoryLimit", ctypes.c_size_t),
        ("JobMemoryLimit", ctypes.c_size_t),
        ("PeakProcessMemoryUsed", ctypes.c_size_t),
        ("PeakJobMemoryUsed", ctypes.c_size_t),
    ]


class JOBOBJECT_BASIC_ACCOUNTING_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("TotalUserTime", ctypes.c_longlong),
        ("TotalKernelTime", ctypes.c_longlong),
        ("ThisPeriodTotalUserTime", ctypes.c_longlong),
        ("ThisPeriodTotalKernelTime", ctypes.c_longlong),
        ("TotalPageFaultCount", wintypes.DWORD),
        ("TotalProcesses", wintypes.DWORD),
        ("ActiveProcesses", wintypes.DWORD),
        ("TotalTerminatedProcesses", wintypes.DWORD),
    ]


_kernel32.CreateJobObjectW.restype = wintypes.HANDLE
_kernel32.CreateJobObjectW.argtypes = [wintypes.LPVOID, wintypes.LPCWSTR]

_kernel32.SetInformationJobObject.restype = wintypes.BOOL
_kernel32.SetInformationJobObject.argtypes = [
    wintypes.HANDLE,
    ctypes.c_int,
    wintypes.LPVOID,
    wintypes.DWORD,
]

_kernel32.QueryInformationJobObject.restype = wintypes.BOOL
_kernel32.QueryInformationJobObject.argtypes = [
    wintypes.HANDLE,
    ctypes.c_int,
    wintypes.LPVOID,
    wintypes.DWORD,
    ctypes.POINTER(wintypes.DWORD),
]

_kernel32.AssignProcessToJobObject.restype = wintypes.BOOL
_kernel32.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]

_kernel32.TerminateJobObject.restype = wintypes.BOOL
_kernel32.TerminateJobObject.argtypes = [wintypes.HANDLE, wintypes.UINT]

_kernel32.CloseHandle.restype = wintypes.BOOL
_kernel32.CloseHandle.argtypes = [wintypes.HANDLE]

_kernel32.GetExitCodeProcess.restype = wintypes.BOOL
_kernel32.GetExitCodeProcess.argtypes = [
    wintypes.HANDLE,
    ctypes.POINTER(wintypes.DWORD),
]

# Windows 上进程被强制终止时，退出码通常是这几个"硬件异常"风格的值。
# 我们不直接依赖它们判 RE——真正的判定靠 killed_reason，这里只用来打日志。
CRASH_EXIT_CODES = {
    0xC0000005: "ACCESS_VIOLATION（空指针 / 野指针解引用）",
    0xC00000FD: "STACK_OVERFLOW（栈溢出，常见于无限递归）",
    0xC0000094: "INTEGER_DIVIDE_BY_ZERO（整数除零）",
    0xC0000409: "STACK_BUFFER_OVERRUN（栈保护被触发）",
    0xC0000135: "DLL_NOT_FOUND（缺少运行时 DLL，ASan 题常见）",
    0x40000015: "FATAL_APP_EXIT（abort() / 未捕获异常）",
}


def _raise_last_error(what: str) -> None:
    err = ctypes.get_last_error()
    raise OSError(f"{what} 失败，Windows 错误码 {err}（0x{err:08X}）")


# =============================================================================
# 结果数据结构
# =============================================================================


@dataclass
class RunResult:
    """一次进程运行的全部可观测信息。判定码由 engine.py 决定，这里只给事实。"""

    exit_code: int = 0
    stdout: str = ""
    stderr: str = ""
    time_ms: int = 0  # 墙钟耗时
    cpu_ms: int = 0  # 用户态 + 内核态 CPU 时间
    peak_mem_mb: float = 0.0  # 进程峰值内存
    max_processes: int = 0  # 运行期间出现过的最大并发进程数
    killed_reason: str = ""  # "", "wall", "cpu", "memory", "output"
    timed_out: bool = False
    crash_hint: str = ""  # 崩溃退出码的人话解释（仅用于展示）
    error: str = ""  # 沙箱自身出错（不是用户代码的错）

    @property
    def ok(self) -> bool:
        return not self.error and not self.killed_reason and self.exit_code == 0


# =============================================================================
# 沙箱主体
# =============================================================================


@dataclass
class Limits:
    """一次判题的限制参数。默认值是给 C++ 学习题用的保守配置。"""

    wall_time_ms: int = 5000  # 墙钟总超时（含程序启动开销）
    cpu_time_ms: int = 3000  # CPU 时间上限，>0 才启用
    memory_mb: int = 512  # 内存上限，<=0 表示不限（ASan 模式用）
    output_bytes: int = 256 * 1024  # stdout+stderr 合计字节上限
    max_processes: int = 8  # 并发进程数上限，防 fork 炸弹
    poll_interval_ms: int = 15  # 主循环轮询间隔


@dataclass
class _JobHandle:
    handle: int = 0

    def close(self) -> None:
        if self.handle:
            _kernel32.CloseHandle(self.handle)
            self.handle = 0


def _make_job(limits: Limits) -> _JobHandle:
    """创建一个 Job Object 并设好所有限制。

    用了 JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE：句柄一关，job 里的所有进程
    （包括用户代码偷偷 fork 出来的子进程）立即被内核清掉。这是"判题后
    不留残余进程"的关键，比手动 kill 可靠得多。
    """
    job = _JobHandle(_kernel32.CreateJobObjectW(None, None))
    if not job.handle:
        _raise_last_error("CreateJobObjectW")

    info = JOBOBJECT_EXTENDED_LIMIT_INFORMATION()
    flags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE | JOB_OBJECT_LIMIT_DIE_ON_UNHANDLED_EXCEPTION

    # 内存上限。注意 ASan 模式下必须传 memory_mb <= 0 跳过——见下方说明。
    if limits.memory_mb and limits.memory_mb > 0:
        flags |= JOB_OBJECT_LIMIT_PROCESS_MEMORY | JOB_OBJECT_LIMIT_JOB_MEMORY
        info.ProcessMemoryLimit = limits.memory_mb * 1024 * 1024
        info.JobMemoryLimit = limits.memory_mb * 1024 * 1024

    # CPU 时间上限（单位 100ns）
    if limits.cpu_time_ms and limits.cpu_time_ms > 0:
        flags |= JOB_OBJECT_LIMIT_PROCESS_TIME
        info.BasicLimitInformation.PerProcessUserTimeLimit = limits.cpu_time_ms * 10_000

    # 并发进程数上限
    if limits.max_processes and limits.max_processes > 0:
        flags |= JOB_OBJECT_LIMIT_ACTIVE_PROCESS
        info.BasicLimitInformation.ActiveProcessLimit = limits.max_processes

    info.BasicLimitInformation.LimitFlags = flags

    ok = _kernel32.SetInformationJobObject(
        job.handle,
        JobObjectExtendedLimitInformation,
        ctypes.byref(info),
        ctypes.sizeof(info),
    )
    if not ok:
        job.close()
        _raise_last_error("SetInformationJobObject")

    return job


def _query_accounting(job: _JobHandle) -> JOBOBJECT_BASIC_ACCOUNTING_INFORMATION:
    """读取 job 的累计 CPU 时间与进程数。"""
    info = JOBOBJECT_BASIC_ACCOUNTING_INFORMATION()
    ret_len = wintypes.DWORD(0)
    _kernel32.QueryInformationJobObject(
        job.handle,
        JobObjectBasicAccountingInformation,
        ctypes.byref(info),
        ctypes.sizeof(info),
        ctypes.byref(ret_len),
    )
    return info


def _query_peak_memory_mb(job: _JobHandle) -> float:
    """读取 job 的峰值内存占用。"""
    info = JOBOBJECT_EXTENDED_LIMIT_INFORMATION()
    ret_len = wintypes.DWORD(0)
    _kernel32.QueryInformationJobObject(
        job.handle,
        JobObjectExtendedLimitInformation,
        ctypes.byref(info),
        ctypes.sizeof(info),
        ctypes.byref(ret_len),
    )
    return info.PeakProcessMemoryUsed / (1024 * 1024)


def _read_text(path: str, limit_bytes: int) -> str:
    """读文件，按字节上限截断，并按 UTF-8 -> GBK 顺序尝试解码。

    Windows 上 clang 的报错是 UTF-8，而 MSVC 是 GBK（代码页 936），
    用户机器上两种都可能出现，所以这里做个兜底。
    """
    try:
        with open(path, "rb") as fh:
            raw = fh.read(limit_bytes + 1)
    except OSError:
        return ""
    truncated = len(raw) > limit_bytes
    if truncated:
        raw = raw[:limit_bytes]
    for enc in ("utf-8", "gbk", "latin-1"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    else:
        text = raw.decode("utf-8", errors="replace")
    if truncated:
        text += "\n...[输出过长已截断]..."
    return text


def run(
    cmd: list[str],
    *,
    limits: Limits | None = None,
    stdin_data: str = "",
    cwd: str | None = None,
    env: dict[str, str] | None = None,
    workdir_root: str | None = None,
) -> RunResult:
    """在受控 Job Object 里跑一个命令，返回 RunResult。

    参数
    ----
    cmd          : 命令行列表，例如 ["clang++", "-std=c++20", "main.cpp", "-o", "a.exe"]
    limits       : 限制参数，None 用默认
    stdin_data   : 喂给进程的标准输入
    cwd          : 工作目录；None 则新建临时目录（判题必须用临时目录）
    env          : 完整环境变量；None 则继承当前进程
    workdir_root : 临时目录的父目录，便于统一清理

    注意：调用方（engine.py）负责在 finally 里删临时目录。这里只在 cwd=None
    时创建目录，不负责删除——因为编译和运行要共用同一个目录。
    """
    limits = limits or Limits()
    result = RunResult()

    own_workdir = cwd is None
    if own_workdir:
        cwd = tempfile.mkdtemp(prefix="cppjudge_", dir=workdir_root)

    out_path = os.path.join(cwd, "__judge_stdout.tmp")
    err_path = os.path.join(cwd, "__judge_stderr.tmp")
    in_path = os.path.join(cwd, "__judge_stdin.tmp")
    if stdin_data:
        with open(in_path, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(stdin_data)
    else:
        # 空文件占位：给进程一个"立刻 EOF"的 stdin，避免某些程序阻塞等输入
        open(in_path, "w").close()

    job = _JobHandle(0)
    proc: subprocess.Popen | None = None
    try:
        job = _make_job(limits)

        creationflags = CREATE_NO_WINDOW | CREATE_NEW_PROCESS_GROUP
        with open(in_path, "rb") as f_in, open(out_path, "wb") as f_out, open(
            err_path, "wb"
        ) as f_err:
            proc = subprocess.Popen(
                cmd,
                stdin=f_in,
                stdout=f_out,
                stderr=f_err,
                cwd=cwd,
                env=env,
                creationflags=creationflags,
            )

            # 把进程塞进 job。这里存在一个极小的竞态窗口：进程在 Popen 返回后、
            # 我们赋值前可能已经 fork 了子进程。对"单用户学习软件"来说无所谓
            # （威胁模型是意外死循环，不是恶意逃逸）；真要严格，得用
            # CreateProcessW(CREATE_SUSPENDED) 先挂起再赋值再 ResumeThread。
            if not _kernel32.AssignProcessToJobObject(job.handle, int(proc._handle)):
                _raise_last_error("AssignProcessToJobObject")

            start = time.perf_counter()
            killed_reason = ""
            while True:
                if proc.poll() is not None:
                    break

                elapsed_ms = (time.perf_counter() - start) * 1000.0

                # 1) 墙钟超时
                if elapsed_ms >= limits.wall_time_ms:
                    killed_reason = "wall"
                    break

                # 2) 输出体积超限（编译一个疯狂展开的模板时会触发）
                try:
                    out_size = os.path.getsize(out_path) + os.path.getsize(err_path)
                except OSError:
                    out_size = 0
                if out_size >= limits.output_bytes:
                    killed_reason = "output"
                    break

                # 3) CPU 时间触顶。这里主动查，是为了在 Job Object 的硬限制
                #    生效前先自己发现，好把原因记成 "cpu" 而不是含糊的 RE。
                acct = _query_accounting(job)
                cpu_ms = (acct.TotalUserTime + acct.TotalKernelTime) / 10_000.0
                if limits.cpu_time_ms and cpu_ms >= limits.cpu_time_ms:
                    killed_reason = "cpu"
                    break

                # 4) 峰值内存触顶
                if limits.memory_mb and limits.memory_mb > 0:
                    peak = _query_peak_memory_mb(job)
                    if peak >= limits.memory_mb * 0.98:
                        killed_reason = "memory"
                        break

                time.sleep(limits.poll_interval_ms / 1000.0)

            result.time_ms = int((time.perf_counter() - start) * 1000.0)

            if killed_reason:
                # TerminateJobObject 会把 job 里的所有进程连同子进程一起清掉
                _kernel32.TerminateJobObject(job.handle, 1)
                try:
                    proc.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    proc.kill()
                result.killed_reason = killed_reason
                result.timed_out = killed_reason in ("wall", "cpu")

            # 收尾：拿退出码与资源统计
            try:
                result.exit_code = proc.returncode if proc.returncode is not None else -1
            except Exception:
                result.exit_code = -1

            acct = _query_accounting(job)
            result.cpu_ms = int((acct.TotalUserTime + acct.TotalKernelTime) / 10_000.0)
            result.max_processes = acct.TotalProcesses
            result.peak_mem_mb = round(_query_peak_memory_mb(job), 1)

        result.stdout = _read_text(out_path, limits.output_bytes)
        result.stderr = _read_text(err_path, limits.output_bytes)

        # 退出码转成"人话"，方便前端直接把原因展示给用户
        if result.exit_code and not result.killed_reason:
            code_u = result.exit_code & 0xFFFFFFFF
            result.crash_hint = CRASH_EXIT_CODES.get(code_u, "")

    except OSError as exc:
        result.error = str(exc)
    finally:
        job.close()  # KILL_ON_JOB_CLOSE 保证此刻没有任何残余进程
        if own_workdir and cwd:
            shutil.rmtree(cwd, ignore_errors=True)

    return result


def run_in_dir(
    cmd: list[str],
    workdir: str,
    *,
    limits: Limits | None = None,
    stdin_data: str = "",
    env: dict[str, str] | None = None,
) -> RunResult:
    """在指定目录里跑命令（编译阶段和运行阶段共用同一个工作目录）。"""
    return run(
        cmd,
        limits=limits,
        stdin_data=stdin_data,
        cwd=workdir,
        env=env,
    )
