"""判题引擎的命令行入口 —— Tauri（Rust 端）通过它调用判题。

===============================================================================
通信协议
===============================================================================
Rust 端 spawn 这个脚本，**用 stdin 传一个 JSON 请求、用 stdout 收一个 JSON 响应**。

不用命令行参数传代码的原因：Windows 命令行有长度上限（约 32767 字符），
而且引号/换行/中文的转义极易出问题。stdin 是二进制安全的，省心。

---------------------------------------------------------------------------
请求（stdin，单个 JSON 对象）
---------------------------------------------------------------------------
{
  "action": "judge",              // "judge" | "detect" | "ping"
  "mode": "output",               // output | compile_fail | asan
  "code": "#include <iostream>...",
  "expected": "42",               // 期望输出；compile_fail 模式忽略
  "stdin": "",                    // 喂给程序的标准输入
  "float_tol": null,              // 浮点容差，null 表示精确比对
  "time_limit_ms": 2000,
  "mem_limit_mb": 512
}

---------------------------------------------------------------------------
响应（stdout，单个 JSON 对象）
---------------------------------------------------------------------------
{
  "ok": true,
  "verdict": "AC",
  "verdictText": "通过",
  "message": "输出正确 ✅",
  "stdout": "42\n",
  "stderr": "",
  "compileOutput": "",
  "timeMs": 12,
  "peakMemMb": 3.4,
  "crashHint": "",
  "sanitizerReport": ""
}

判题结果永远通过 JSON 返回，进程退出码只表示"通信/系统级"成败：
    0 = 正常返回了 JSON（哪怕判定结果是 WA）
    2 = 请求 JSON 本身有问题
    3 = 引擎内部异常（已在 JSON 的 message 里给出原因）
"""

from __future__ import annotations

import json
import os
import sys
import traceback

# 保证中文和 emoji 在各种 Windows 控制台代码页下都不乱码
try:
    sys.stdout.reconfigure(encoding="utf-8", newline="\n")
    sys.stdin.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except (AttributeError, ValueError):
    pass

import engine  # noqa: E402
import toolchain  # noqa: E402


def _emit(payload: dict) -> None:
    sys.stdout.write(json.dumps(payload, ensure_ascii=False))
    sys.stdout.flush()


def _handle_detect() -> dict:
    """报告本机工具链情况，供前端"环境自检"页面展示。"""
    try:
        tc = toolchain.detect()
    except RuntimeError as exc:
        return {"ok": False, "message": str(exc), "toolchain": None}
    return {
        "ok": True,
        "toolchain": {
            "name": tc.name,
            "cxx": tc.cxx,
            "version": tc.version,
            "supportsAsan": tc.supports_asan,
            "asanDllDir": tc.asan_dll_dir,
            "sourceDir": tc.source_dir,
        },
    }


def _chapter_platform(chapter_id: str) -> str:
    """读 chapters/<chapter_id>.json 的 platform 字段（缺省按 windows 处理）。

    从 judge/ 的上一级找 chapters/（开发目录布局）；找不到就当 windows，
    对 L0~L9 的行为零影响。
    """
    if not chapter_id:
        return ""
    here = os.path.dirname(os.path.abspath(__file__))
    for root in (os.path.dirname(here), here):
        p = os.path.join(root, "chapters", f"{chapter_id}.json")
        try:
            with open(p, encoding="utf-8") as fh:
                return (json.load(fh).get("platform") or "").strip().lower()
        except Exception:
            continue
    return ""


def _judge_linux(req: dict, chapter_id: str) -> dict:
    """platform=linux 章节：经 linux_judge（ExecutionBackend：LinuxNative / WSL2）判题。

    请求/响应结构与 engine 路径完全一致（前端无感知）。
    """
    import linux_judge

    ex = {
        "id": f"{chapter_id}-?",
        "mode": req.get("mode", "output"),
        "code": req.get("code", "") or "",
        "expected": req.get("expected", "") or "",
        "stdin": req.get("stdin", "") or "",
        "tests": req.get("tests") or [],
        "choices": req.get("choices") or [],
    }
    if req.get("float_tol") is not None:
        ex["floatTol"] = req["float_tol"]
    v = linux_judge.judge_exercise(ex, answer=req.get("answer", "") or "")
    return {"ok": True, **v.to_dict()}


def main() -> int:
    raw = sys.stdin.read()
    if not raw.strip():
        _emit({"ok": False, "message": "没有收到请求内容（stdin 为空）", "verdict": "SE"})
        return 2

    try:
        req = json.loads(raw)
    except json.JSONDecodeError as exc:
        _emit({"ok": False, "message": f"请求 JSON 解析失败：{exc}", "verdict": "SE"})
        return 2

    action = req.get("action", "judge")

    try:
        if action == "ping":
            _emit({"ok": True, "message": "pong"})
            return 0

        if action == "detect":
            _emit(_handle_detect())
            return 0

        if action != "judge":
            _emit({"ok": False, "message": f"未知 action：{action!r}", "verdict": "SE"})
            return 2

        chapter_id = (req.get("chapter_id") or "").strip()
        if chapter_id and _chapter_platform(chapter_id) == "linux":
            _emit(_judge_linux(req, chapter_id))
            return 0

        verdict = engine.judge_case(
            mode=req.get("mode", "output"),
            code=req.get("code", ""),
            expected=req.get("expected", "") or "",
            stdin_data=req.get("stdin", "") or "",
            # predictOutput 模式用：用户填的预测输出（不是代码）
            answer=req.get("answer", "") or "",
            # multipleChoice 模式用：完整选项数组（含 correct / why），不下发前端
            choices=req.get("choices") or [],
            # 多测试题（Level Challenge）用：为空则回退到单个 expected
            tests=req.get("tests") or [],
            float_tol=req.get("float_tol"),
            time_limit_ms=int(req.get("time_limit_ms") or engine.DEFAULT_TIME_LIMIT_MS),
            mem_limit_mb=int(req.get("mem_limit_mb") or engine.DEFAULT_MEM_LIMIT_MB),
        )
        payload = {"ok": True, **verdict.to_dict()}
        _emit(payload)
        return 0

    except Exception as exc:  # noqa: BLE001 - 最外层兜底，不能让判题器静默死掉
        _emit(
            {
                "ok": False,
                "verdict": "SE",
                "verdictText": "判题系统错误",
                "message": f"判题引擎内部异常：{exc}",
                "traceback": traceback.format_exc(),
            }
        )
        return 3


if __name__ == "__main__":
    sys.exit(main())
