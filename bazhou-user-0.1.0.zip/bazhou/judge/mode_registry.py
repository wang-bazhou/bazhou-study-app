"""题型注册表 —— **所有题型能力的单一事实源**。

===============================================================================
为什么需要它（架构审查 2026-09-22 的第二条）
===============================================================================
改造前，新增一个题型要手工同步至少 13 处（前端 MODE/MODE_LABEL/modeOf/题型
UI 分派/runJudge/判定渲染、Rust ExerciseSpec/import 白名单、Python
MODE_ALIASES/mode 集合/judge_case、validate_chapters、check_content_health、
导入器、题型测试）。任何一处漏改就是静默漂移 —— 实测已有两起：

  · import.rs 的 VALID_MODES 只剩 4 个老题型（新题型的章节会被导入器拒绝）；
  · run_judge.py 的 Linux 路由排除表漏了 diagnose（纯文本题被错送 Linux
    后端，报「暂不支持」SE）。

现在**能力**在这里声明一次，各处按能力查询：

  engine.py            —— normalize_mode / 各 mode 集合从这里派生
  validate_chapters.py —— 题型合法性与能力断言
  check_content_health.py —— 判题强度提示与路由口径
  run_judge.py         —— 路由判定（local_only / needs_linux）
  Rust import.rs       —— VALID_MODES（通过 run_judge 的 detect 扩展读取；
                        编译期常量保持同步注释锚点，见 SYNC-ANCHOR）
  前端 modes.js        —— 渲染/提交/判定展示分派（同名注册表）

字段说明（能力即合同）：
  aliases       驼峰/下划线/短名等全部合法写法（归一到 canonical）
  canonical     规范名（Python 内部用下划线风格）
  wire          线上写法（JSON 里出现的名字 —— 前端/章节 JSON 用驼峰）
  kind          题型族：code | text | choice | file | embed | run
  needs_answer  判题时需要"参考答案"（expected / tests / asserts 之一）
  needs_code    用户要交代码（要跑"初始状态不得直接通过"）
  local_only    必须在 Windows 本地判（纯解析 / 自带解释器 / busybox-w32）
  needs_linux   platform=linux 章节里要经 Linux 后端（真跑/真交叉编译）
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class ModeSpec:
    canonical: str                 # Python 内部名（下划线风格）
    wire: str                      # JSON 线上名（驼峰风格）
    aliases: tuple[str, ...] = field(default_factory=tuple)
    kind: str = "code"
    needs_answer: bool = True
    needs_code: bool = True
    local_only: bool = False
    needs_linux: bool = False


# ── SYNC-ANCHOR：改这里时同步 src/modes.js（前端注册表）────────────────────
MODES: tuple[ModeSpec, ...] = (
    ModeSpec("output", "output", ("output_test",), kind="code", needs_linux=True),
    ModeSpec("compile_fail", "compileFail", ("compilefail", "compile-fail"), kind="code"),
    ModeSpec("asan", "asan", ("sanitizer",), kind="code"),
    ModeSpec("predict_output", "predictOutput", ("predictoutput", "predict-output"),
             kind="text", needs_code=False, needs_linux=True),
    ModeSpec("multiple_choice", "multipleChoice", ("multiplechoice", "multiple-choice",
                                                   "choice", "choices"),
             kind="choice", needs_code=False, local_only=True),
    # 只运行不判定的三个实验模式（run 走编译器；shell_run / python_run 各自的语言面）
    ModeSpec("run", "run", ("runonly", "run_only"), kind="run",
             needs_answer=False, needs_code=False, local_only=True),
    ModeSpec("shell_run", "shell_run", ("shellrun", "shell-run", "shellrunonly"),
             kind="run", needs_answer=False, needs_code=False, local_only=True),
    ModeSpec("python_run", "python_run", ("pythonrun", "python-run", "py_run"),
             kind="run", needs_answer=False, needs_code=False, local_only=True),
    ModeSpec("shell", "shell", ("bash", "sh"), kind="file", local_only=True),
    ModeSpec("config", "config", ("yaml", "dockerfile"), kind="file",
             needs_code=False, local_only=True),
    ModeSpec("diagnose", "diagnose", ("diagnosis", "troubleshoot"), kind="text",
             needs_code=False, local_only=True),
    ModeSpec("python", "python", ("py",), kind="code", local_only=True),
    ModeSpec("embed", "embed", ("embedded", "mcu"), kind="embed"),
)

CANONICAL: dict[str, ModeSpec] = {m.canonical: m for m in MODES}

_ALIAS_MAP: dict[str, str] = {}
for _m in MODES:
    _ALIAS_MAP[_m.canonical.lower()] = _m.canonical
    _ALIAS_MAP[_m.wire.lower()] = _m.canonical
    for _a in _m.aliases:
        _ALIAS_MAP[_a.lower()] = _m.canonical


def normalize(raw: str) -> str:
    """任意合法写法 → 规范名；不认识的原样小写返回（由调用方决定报错还是回退）。"""
    key = (raw or "").strip().lower()
    return _ALIAS_MAP.get(key, key)


def known(raw: str) -> bool:
    return normalize(raw) in CANONICAL


def all_wire_names() -> list[str]:
    """全部合法写法（Rust 导入器白名单 / 校验器的接受表）。"""
    out: list[str] = []
    for m in MODES:
        out.append(m.wire)
        out.append(m.canonical)
        out.extend(m.aliases)
    return out


def code_modes() -> set[str]:
    return {m.canonical for m in MODES if m.needs_code and m.kind == "code"}


def answer_modes() -> set[str]:
    """需要非空参考答案的题型（validate_chapters 的断言用）。"""
    return {m.canonical for m in MODES if m.needs_answer}


def run_only_modes() -> set[str]:
    """只运行不判定的实验模式（run / shell_run / python_run）。"""
    return {m.canonical for m in MODES if m.kind == "run"}


def predict_modes() -> set[str]:
    return {m.canonical for m in MODES if m.kind == "text" and m.canonical.startswith("predict")}


def choice_modes() -> set[str]:
    return {m.canonical for m in MODES if m.kind == "choice"}


def alias_map() -> dict[str, str]:
    """全部合法写法 → 规范名（engine.MODE_ALIASES 的同源数据）。"""
    return dict(_ALIAS_MAP)


def local_only(raw: str) -> bool:
    m = CANONICAL.get(normalize(raw))
    return bool(m and m.local_only)


def needs_linux(raw: str) -> bool:
    """platform=linux 章节里，这种题型要不要送 Linux 后端（真跑/交叉编译）。

    run_judge.py 的路由**只按这一条**判断 —— 与 check_content_health 的
    「output / predict_output 经 linux_judge」口径一致。
    """
    m = CANONICAL.get(normalize(raw))
    return bool(m and m.needs_linux)


def judge_modes() -> set[str]:
    """可判题型（不含 run —— run 只运行不判定）。"""
    return {m.canonical for m in MODES if m.canonical != "run"}
