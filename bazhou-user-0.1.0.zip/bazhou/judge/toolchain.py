"""工具链探测：找到本机可用的 C++ 编译器，以及 ASan 运行时 DLL。

设计原则（来自交接文档第三条）：**优先复用用户已有环境，零下载**。
本机实测结果（2026-09-11）：

    编译器      状态
    ----------+-----------------------------------------------
    clang++    OK, 22.1.8, C:\\Program Files\\LLVM\\bin
    cl.exe     OK, Visual Studio 18 Community
    g++        未安装

所以默认首选 clang++，MSVC 作为备选。将来如果换了机器，这个模块会自动
重新探测，不需要改代码。
"""

from __future__ import annotations

import glob
import os
import shutil
import subprocess
import sys
from dataclasses import dataclass

CREATE_NO_WINDOW = 0x08000000


@dataclass
class Toolchain:
    """一套可用的编译环境。"""

    name: str  # "clang" / "msvc"
    cxx: str  # 编译器可执行文件绝对路径
    version: str = ""
    asan_dll_dir: str = ""  # ASan 运行时 DLL 所在目录，需加进子进程 PATH
    source_dir: str = ""  # 编译器所属安装目录，便于排查

    @property
    def supports_asan(self) -> bool:
        return bool(self.asan_dll_dir)


def _run_version(exe: str, args: list[str]) -> str:
    try:
        out = subprocess.run(
            [exe, *args],
            capture_output=True,
            timeout=15,
            creationflags=CREATE_NO_WINDOW if sys.platform == "win32" else 0,
        )
        text = (out.stdout or out.stderr).decode("utf-8", errors="replace")
        return text.strip().splitlines()[0] if text.strip() else ""
    except Exception:
        return ""


def _bundled_root() -> str:
    """软件目录里的判题运行时（`<软件目录>\\runtime\\`）。

    Rust 侧启动判题子进程时会设 `BAZHOU_RUNTIME_DIR`。这条路径是"用户电脑上
    什么都不用装"的落点：编译器由软件自己下到软件目录里（见 src-tauri/src/runtime.rs）。
    """
    return (os.environ.get("BAZHOU_RUNTIME_DIR") or "").strip()


def _find_bundled_clang() -> Toolchain | None:
    """优先找**软件目录里自带**的 clang++（llvm-mingw）。

    为什么它排在 PATH 前面：这是软件自己准备的那套环境，用户明确选了它
    （"我们提供检测和安装程序，装到软件目录"）。用户自己装的编译器仍然可用，
    但要让位给自带的这套——否则"装了却没用上"会让人以为安装失败了。
    """
    root = _bundled_root()
    if not root:
        return None
    exe = os.path.join(root, "llvm", "bin", "clang++.exe")
    if not os.path.isfile(exe):
        return None
    llvm_root = os.path.dirname(os.path.dirname(exe))       # ...\runtime\llvm
    return Toolchain(
        name="clang(自带)",
        cxx=exe,
        version=_run_version(exe, ["--version"]),
        asan_dll_dir=_find_asan_dir(llvm_root),
        source_dir=llvm_root,
    )


def _find_clang() -> Toolchain | None:
    """找 clang++。顺序：软件目录自带的 → PATH → LLVM 默认安装目录。"""
    bundled = _find_bundled_clang()
    if bundled:
        return bundled
    exe = shutil.which("clang++")
    if not exe:
        for guess in (
            r"C:\Program Files\LLVM\bin\clang++.exe",
            r"C:\Program Files (x86)\LLVM\bin\clang++.exe",
        ):
            if os.path.isfile(guess):
                exe = guess
                break
    if not exe:
        return None

    llvm_root = os.path.dirname(os.path.dirname(exe))  # ...\LLVM\bin\clang++ -> ...\LLVM
    asan_dir = _find_asan_dir(llvm_root)

    return Toolchain(
        name="clang",
        cxx=exe,
        version=_run_version(exe, ["--version"]),
        asan_dll_dir=asan_dir,
        source_dir=llvm_root,
    )


def _find_asan_dir(llvm_root: str) -> str:
    """定位 ASan 运行库（Windows 上踩过的坑）。

    clang 编译 `-fsanitize=address` 的程序时，生成的可执行文件会**动态**依赖
    ASan 运行库；它不在 PATH 里时，程序启动即失败（退出码 0xC0000135），
    会被误判成 RE，而不是检测到越界。

    两种布局都要认（实测）：
      · LLVM 官方安装版：`<root>/lib/clang/<ver>/lib/windows/clang_rt.asan_dynamic-x86_64.dll`
      · llvm-mingw（软件自带那套）：`<root>/bin/libclang_rt.asan_dynamic-x86_64.dll`

    单测里对此有专门用例，见 judge/tests/test_sandbox.py::test_asan_dll_missing
    """
    patterns = [
        os.path.join(llvm_root, "lib", "clang", "*", "lib", "windows", "clang_rt.asan_dynamic-x86_64.dll"),
        os.path.join(llvm_root, "lib", "clang", "*", "lib", "windows", "clang_rt.asan_dynamic*.dll"),
        os.path.join(llvm_root, "bin", "libclang_rt.asan_dynamic-x86_64.dll"),
        os.path.join(llvm_root, "bin", "libclang_rt.asan_dynamic*.dll"),
    ]
    for pattern in patterns:
        hits = glob.glob(pattern)
        if hits:
            # 版本号可能有多份，取版本最高的
            hits.sort(reverse=True)
            return os.path.dirname(hits[0])
    return ""


def _find_msvc() -> Toolchain | None:
    """找 MSVC cl.exe。

    cl.exe 通常不在 PATH 里（要跑 vcvarsall.bat 才进 PATH），所以直接按
    目录结构找：<VS>/<ver>/<edition>/VC/Tools/MSVC/<ver>/bin/Hostx64/x64/cl.exe
    """
    if sys.platform != "win32":
        return None
    roots = [
        r"C:\Program Files\Microsoft Visual Studio",
        r"C:\Program Files (x86)\Microsoft Visual Studio",
    ]
    for root in roots:
        pattern = os.path.join(root, "*", "*", "VC", "Tools", "MSVC", "*", "bin", "Hostx64", "x64", "cl.exe")
        hits = glob.glob(pattern)
        if hits:
            hits.sort(reverse=True)
            exe = hits[0]
            return Toolchain(
                name="msvc",
                cxx=exe,
                version=_run_version(exe, []),
                asan_dll_dir="",  # MSVC 的 ASan 需要 vcvars 环境，暂不支持
                source_dir=os.path.dirname(exe),
            )
    return None


_CACHE: Toolchain | None = None


def detect(prefer: str | None = None) -> Toolchain:
    """探测并缓存本机工具链。

    prefer 可以是 "clang" / "msvc"；None 表示自动选（clang 优先）。
    """
    global _CACHE
    if _CACHE is not None and prefer is None:
        return _CACHE

    clang = _find_clang()
    msvc = _find_msvc()

    if prefer == "msvc" and msvc:
        return msvc
    if prefer == "clang" and clang:
        return clang

    chosen = clang or msvc
    if chosen is None:
        raise RuntimeError(
            "本机没有找到可用的 C++ 编译器（clang++ / cl.exe 都没有）。\n"
            "请安装 LLVM（https://releases.llvm.org）或 Visual Studio，"
            "然后重新启动本软件。"
        )
    if prefer is None:
        _CACHE = chosen
    return chosen


def make_env(toolchain: Toolchain, extra: dict[str, str] | None = None) -> dict[str, str]:
    """构造子进程环境变量。

    ASan 模式必须走这里：把 clang_rt.asan_dynamic-x86_64.dll 的目录塞进
    PATH，否则带 sanitizer 的程序一启动就找不到 DLL。
    """
    env = dict(os.environ)
    if toolchain.asan_dll_dir:
        env["PATH"] = toolchain.asan_dll_dir + os.pathsep + env.get("PATH", "")
    if extra:
        env.update(extra)
    return env


def asan_env_options(toolchain: Toolchain) -> dict[str, str]:
    """ASan 在受限环境下的必需选项（来自交接文档踩坑记录第 2 条）。

    - detect_leaks=0   : LeakSanitizer 在受限容器/沙箱里会 fatal error，
                         而泄漏检测本来也不是我们这几道题要考的东西。
    - abort_on_error=0 : 让 ASan 报错后正常返回，我们靠退出码判 WA，
                         而不是让进程直接 abort 把判题器带崩。
    """
    return {
        "ASAN_OPTIONS": "detect_leaks=0:abort_on_error=0:exitcode=1",
        "UBSAN_OPTIONS": "halt_on_error=1:print_stacktrace=0",
    }
