#!/usr/bin/env python3
"""L10 最小 ExecutionBackend（干净重写版，修复了多次 patch 导致的不一致）。

【安全边界声明——必须原样理解，不得夸大】
本执行器仅用于用户主动运行自己的、可信的个人练习代码。
它不是安全沙箱，不得用于运行不可信第三方代码。

已实现的控制（部分资源控制）：
- 每次执行使用独立临时工作目录（mkdtemp），结束后清理
- 编译/运行超时；Linux 侧超时后 killpg 清理整个进程组
- 运行结束后对 stdout/stderr 做 post-hoc 截断（output_limit_bytes）

尚未实现的已知缺口（记录在案，宣称能力时不得包含以下各项）：
- 运行期输出限制：截断发生在运行结束后，进程运行中仍可能写爆内存/磁盘/管道
- 内存限制：RunRequest.memory_limit_mb 仅为字段占位，未生效
  （Linux 侧应接入 rlimit/setrlimit，尚未接入）
- 源文件路径校验：source_files 的 key 未做规范化检查，
  理论上可写到工作目录之外（当前仅限用户写自己的文件，风险可控但需记录）
- 无网络访问控制、无文件系统隔离、无用户/权限隔离

不可信第三方代码需要具备文件系统、进程、网络和权限隔离的专用执行环境；
不得用普通 Docker 容器或资源限制冒充完整安全隔离。
"""
from __future__ import annotations

import os
import platform
import shutil
import signal
import subprocess
import tempfile
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path, PureWindowsPath
from typing import Optional


class BackendState(Enum):
    AVAILABLE = "AVAILABLE"
    NOT_INSTALLED = "NOT_INSTALLED"
    ACCESS_DENIED = "ACCESS_DENIED"
    COMPILER_MISSING = "COMPILER_MISSING"
    CAPABILITY_UNAVAILABLE = "CAPABILITY_UNAVAILABLE"
    PROBE_FAILED = "PROBE_FAILED"


@dataclass
class CompileRequest:
    source_files: dict[str, str]
    compile_flags: list[str] = field(default_factory=lambda: ["-std=c++20", "-Wall"])
    link_flags: list[str] = field(default_factory=list)
    entry_point: str = "main.cpp"


@dataclass
class RunRequest:
    stdin: str = ""
    time_limit_s: int = 10
    memory_limit_mb: int = 256  # 未实现：仅字段占位，见模块 docstring 已知缺口
    output_limit_bytes: int = 65536  # post-hoc 截断（运行结束后），非运行期限制
    env_extra: dict[str, str] = field(default_factory=dict)
    # 运行前在工作目录中预置的文件（相对路径 → 内容）。供多场景行为测试使用
    # （如「文件已存在」反例）；路径相对工作目录，由执行器保证落在私有目录内。
    prefiles: dict[str, str] = field(default_factory=dict)


@dataclass
class CompileResult:
    success: bool
    diagnostics: str = ""


@dataclass
class RunResult:
    exit_code: Optional[int] = None
    signal: Optional[int] = None
    stdout: str = ""
    stderr: str = ""
    timed_out: bool = False


@dataclass
class ExecutionResult:
    compile: CompileResult
    run: Optional[RunResult] = None
    workdir: str = ""


class ExecutionBackend(ABC):
    @abstractmethod
    def backend_id(self) -> str: ...
    @abstractmethod
    def state(self) -> BackendState: ...
    @abstractmethod
    def capabilities(self) -> frozenset[str]: ...
    @abstractmethod
    def probe(self) -> bool: ...
    @abstractmethod
    def execute(self, creq: CompileRequest, rreq: RunRequest) -> ExecutionResult: ...


def _probe_cpp(backend: ExecutionBackend) -> bool:
    try:
        r = backend.execute(
            CompileRequest(
                source_files={"main.cpp": "int main(){return 0;}"},
                compile_flags=["-std=c++20"], entry_point="main.cpp"),
            RunRequest(time_limit_s=10))
        return r.compile.success and r.run is not None and r.run.exit_code == 0
    except Exception:
        return False


class WindowsClangBackend(ExecutionBackend):
    """Windows 本机 clang++ 编译运行（L0~L9 已有的工具链）。"""

    _probe_cache: Optional[bool] = None

    def backend_id(self) -> str:
        return "windows-clang"

    def state(self) -> BackendState:
        compiler = shutil.which("clang++") or r"C:\Program Files\LLVM\bin\clang++.exe"
        if not os.path.isfile(compiler):
            return BackendState.COMPILER_MISSING
        if self._probe_cache is None:
            self._probe_cache = self.probe()
        return BackendState.AVAILABLE if self._probe_cache else BackendState.PROBE_FAILED

    def capabilities(self) -> frozenset[str]:
        return frozenset({"cpp20", "asan", "ubsan"})

    def probe(self) -> bool:
        if self._probe_cache is None:
            self._probe_cache = _probe_cpp(self)
        return self._probe_cache

    def execute(self, creq: CompileRequest, rreq: RunRequest) -> ExecutionResult:
        wd = Path(tempfile.mkdtemp(prefix="judge_win_"))
        result = ExecutionResult(compile=CompileResult(success=False), workdir=str(wd))
        try:
            for fname, content in creq.source_files.items():
                fp = wd / fname
                fp.parent.mkdir(parents=True, exist_ok=True)
                fp.write_text(content, encoding="utf-8")

            src = str(wd / creq.entry_point)
            exe = str(wd / "a.exe")
            compiler = shutil.which("clang++") or r"C:\Program Files\LLVM\bin\clang++.exe"
            cmd = [compiler, *creq.compile_flags, src, "-o", exe, *creq.link_flags]
            c = subprocess.run(cmd, capture_output=True, text=True,
                               timeout=rreq.time_limit_s)
            result.compile = CompileResult(success=(c.returncode == 0),
                                           diagnostics=c.stderr)
            if not result.compile.success:
                return result

            env = {**os.environ, "LC_ALL": "C", **rreq.env_extra}  # 判题 locale 固定为 C
            try:
                proc = subprocess.run(
                    [exe], input=rreq.stdin.encode("utf-8", errors="replace"),
                    capture_output=True, timeout=rreq.time_limit_s,
                    cwd=str(wd), env=env)
                so = proc.stdout[:rreq.output_limit_bytes].decode("utf-8", errors="replace")
                se = proc.stderr[:rreq.output_limit_bytes].decode("utf-8", errors="replace")
                result.run = RunResult(exit_code=proc.returncode, stdout=so, stderr=se)
            except subprocess.TimeoutExpired:
                result.run = RunResult(timed_out=True)
            return result
        except Exception as e:
            result.compile = CompileResult(success=False, diagnostics=str(e))
            return result
        finally:
            shutil.rmtree(wd, ignore_errors=True)


class LinuxNativeBackend(ExecutionBackend):
    """Linux 本机 g++/clang++ 编译运行。"""

    _probe_cache: Optional[bool] = None

    def backend_id(self) -> str:
        return "linux-native"

    def state(self) -> BackendState:
        compiler = shutil.which("g++") or shutil.which("clang++")
        if not compiler:
            return BackendState.COMPILER_MISSING
        if self._probe_cache is None:
            self._probe_cache = self.probe()
        return BackendState.AVAILABLE if self._probe_cache else BackendState.PROBE_FAILED

    def capabilities(self) -> frozenset[str]:
        return frozenset({
            "cpp20", "asan", "ubsan",
            "fork", "signal", "socket", "epoll",
            "file-io", "pipe", "shared-memory",
        })

    def probe(self) -> bool:
        if self._probe_cache is None:
            self._probe_cache = _probe_cpp(self)
        return self._probe_cache

    def execute(self, creq: CompileRequest, rreq: RunRequest) -> ExecutionResult:
        wd = Path(tempfile.mkdtemp(prefix="judge_linux_"))
        result = ExecutionResult(compile=CompileResult(success=False), workdir=str(wd))
        try:
            for fname, content in creq.source_files.items():
                fp = wd / fname
                fp.parent.mkdir(parents=True, exist_ok=True)
                fp.write_text(content, encoding="utf-8")

            src = str(wd / creq.entry_point)
            exe = str(wd / "a.out")
            compiler = shutil.which("g++") or shutil.which("clang++") or "g++"
            cmd = [compiler, *creq.compile_flags, src, "-o", exe, *creq.link_flags]
            c = subprocess.run(cmd, capture_output=True, text=True,
                               timeout=rreq.time_limit_s)
            result.compile = CompileResult(success=(c.returncode == 0),
                                           diagnostics=c.stderr)
            if not result.compile.success:
                return result

            env = {**os.environ, "LC_ALL": "C", **rreq.env_extra}  # 判题 locale 固定为 C
            for pf_name, pf_content in rreq.prefiles.items():
                pfp = wd / pf_name                      # 相对工作目录，落在私有目录内
                pfp.parent.mkdir(parents=True, exist_ok=True)
                pfp.write_text(pf_content, encoding="utf-8")
            proc = subprocess.Popen(
                [exe], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                stderr=subprocess.PIPE, cwd=str(wd), env=env,
                start_new_session=True)
            try:
                so, se = proc.communicate(
                    input=rreq.stdin.encode("utf-8", errors="replace"),
                    timeout=rreq.time_limit_s)
                so = so[:rreq.output_limit_bytes].decode("utf-8", errors="replace")
                se = se[:rreq.output_limit_bytes].decode("utf-8", errors="replace")
                sig = None
                rc = proc.returncode
                if rc is not None and rc < 0:
                    sig = -rc
                    rc = None
                result.run = RunResult(exit_code=rc, signal=sig, stdout=so, stderr=se)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                except ProcessLookupError:
                    pass
                so, se = proc.communicate()
                result.run = RunResult(timed_out=True,
                                       stdout=so[:rreq.output_limit_bytes].decode("utf-8", errors="replace"),
                                       stderr=se[:rreq.output_limit_bytes].decode("utf-8", errors="replace"))
            return result
        except Exception as e:
            result.compile = CompileResult(success=False, diagnostics=str(e))
            return result
        finally:
            shutil.rmtree(wd, ignore_errors=True)


class WSL2Backend(ExecutionBackend):
    """Windows 经 wsl.exe 调用 WSL2 发行版内的 g++ 编译运行（最小实现）。

    安全边界同模块声明：只面向用户主动运行的可信练习代码，不是安全沙箱。
    TODO(安全缺口，与模块 docstring 的清单对应)：
      - WSL 侧进程组清理未实现：超时杀掉 wsl.exe 不保证终止 Linux 侧进程
      - 无运行期内存/输出限制；env_extra 仅做最小 export 透传
      - 源文件路径校验缺失（与 WindowsClangBackend 同一缺口）
    wsl.exe 自身的 stderr 警告（如 localhost 代理提示，UTF-16 乱码形态）
    会混入 stderr，但不影响 stdout 判定，属已知噪声。
    """

    _probe_cache: Optional[bool] = None
    _distro_cache: Optional[str] = None

    def backend_id(self) -> str:
        return "wsl2"

    # ---- 基础设施探测 ---------------------------------------------
    @staticmethod
    def _wsl_exe() -> Optional[str]:
        for cand in (r"C:\Windows\System32\wsl.exe", shutil.which("wsl.exe")):
            if cand and os.path.isfile(cand):
                return cand
        return None

    @staticmethod
    def _decode_list_output(raw: bytes) -> list[str]:
        # wsl.exe --list 的输出为 UTF-16LE（含 \r\n）
        for enc in ("utf-16-le", "utf-8"):
            try:
                txt = raw.decode(enc, errors="ignore")
            except Exception:
                continue
            names = [ln.strip().strip("\x00") for ln in txt.replace("\r", "\n").split("\n")]
            names = [n for n in names if n]
            if names:
                return names
        return []

    def _pick_distro(self) -> Optional[str]:
        if self._distro_cache is not None:
            return self._distro_cache
        exe = self._wsl_exe()
        if not exe:
            return None
        try:
            p = subprocess.run([exe, "--list", "--quiet"], capture_output=True, timeout=20)
        except Exception:
            return None
        if p.returncode != 0:
            return None
        names = self._decode_list_output(p.stdout)
        forced = os.environ.get("WB_WSL_DISTRO")
        if forced and forced in names:
            self._distro_cache = forced
            return forced
        for n in names:
            if not n.lower().startswith("docker-desktop"):
                self._distro_cache = n
                return n
        return None

    @staticmethod
    def _to_wsl_path(win_path: str) -> str:
        """Windows 路径 → /mnt/<盘>/... 形式（备用工具）。

        注意：本机 WSL 未启用 /mnt 自动挂载，execute() 已改走 stdin 传输 +
        WSL 内部 /tmp 独立目录，不依赖此函数；保留供手动挂载场景使用。
        """
        p = PureWindowsPath(win_path)
        drive = p.drive.rstrip(":").lower()
        tail = str(p.as_posix()).split(":", 1)[-1]
        return f"/mnt/{drive}{tail}"

    def backend_state(self) -> BackendState:  # 兼容旧命名占位（未使用）
        return self.state()

    def state(self) -> BackendState:
        if self._pick_distro() is None:
            return BackendState.NOT_INSTALLED
        if self._probe_cache is None:
            self._probe_cache = self.probe()
        return BackendState.AVAILABLE if self._probe_cache else BackendState.PROBE_FAILED

    def capabilities(self) -> frozenset[str]:
        # 与 LinuxNative 相同：WSL2 内就是真 Linux 用户态
        return frozenset({
            "cpp20", "asan", "ubsan",
            "fork", "signal", "socket", "epoll",
            "file-io", "pipe", "shared-memory",
        })

    def probe(self) -> bool:
        if self._probe_cache is None:
            self._probe_cache = _probe_cpp(self)
        return self._probe_cache

    def execute(self, creq: CompileRequest, rreq: RunRequest) -> ExecutionResult:
        """三阶段执行：源码经 stdin 传入 WSL 内部 /tmp 独立目录（不依赖 /mnt 挂载）。

        Phase1 建目录+写主源码；Phase2 编译；Phase3 运行；finally 清理。
        """
        distro = self._pick_distro()
        if not distro:
            return ExecutionResult(
                compile=CompileResult(success=False, diagnostics="WSL: 未找到可用发行版"))
        wsl_exe = self._wsl_exe()
        base = [wsl_exe, "-d", distro, "-e", "bash", "-c"]
        td = None
        result = ExecutionResult(compile=CompileResult(success=False))
        try:
            # Phase 1：WSL 侧独立临时目录 + 主源码经 stdin 传输
            p1 = subprocess.run(
                base + ['TD=$(mktemp -d /tmp/judge_wsl_XXXXXX) && cat > "$TD/main.cpp" && printf %s "$TD"'],
                input=creq.source_files.get(creq.entry_point, "").encode("utf-8", errors="replace"),
                capture_output=True, timeout=30)
            if p1.returncode != 0:
                d = (p1.stderr or p1.stdout).decode("utf-8", errors="replace")
                result.compile = CompileResult(success=False, diagnostics=d[:2000])
                return result
            td = p1.stdout.decode("ascii", errors="ignore").strip().splitlines()[-1].strip()
            result.workdir = td
            for fname, content in creq.source_files.items():
                if fname == creq.entry_point:
                    continue
                subprocess.run(base + [f'cat > "{td}/{fname}"'],
                               input=content.encode("utf-8", errors="replace"),
                               capture_output=True, timeout=30)

            # Phase 2：编译
            flags = " ".join(creq.compile_flags)
            link = " ".join(creq.link_flags)
            c = subprocess.run(
                base + [f'g++ {flags} "{td}/{creq.entry_point}" -o "{td}/a.out" {link}'.strip()],
                capture_output=True, timeout=max(rreq.time_limit_s, 60))
            result.compile = CompileResult(success=(c.returncode == 0),
                                           diagnostics=c.stderr.decode("utf-8", errors="replace"))
            if not result.compile.success:
                return result

            # Phase 3：运行（cd 进私有临时目录：实验可用相对路径读写，文件不落共享 /tmp）
            # 运行前预置文件（多场景行为测试；相对路径，落在本组私有工作目录内）
            for pf_name, pf_content in rreq.prefiles.items():
                subprocess.run(base + [f'cat > "{td}/{pf_name}"'],
                               input=pf_content.encode("utf-8", errors="replace"),
                               capture_output=True, timeout=30)
            exports = ['export LC_ALL="C"'] + [f'export {k}="{v}"' for k, v in rreq.env_extra.items()]
            run_cmd = "; ".join(exports + [f'cd "{td}" && "./a.out"'])
            try:
                proc = subprocess.run(
                    base + [run_cmd],
                    input=rreq.stdin.encode("utf-8", errors="replace"),
                    capture_output=True, timeout=rreq.time_limit_s)
                so = proc.stdout[:rreq.output_limit_bytes].decode("utf-8", errors="replace")
                se = proc.stderr[:rreq.output_limit_bytes].decode("utf-8", errors="replace")
                sig = None
                rc = proc.returncode
                # bash 对被信号终止的程序返回 128+sig，wsl.exe 透传
                if rc is not None and rc > 128:
                    sig = rc - 128
                    rc = None
                result.run = RunResult(exit_code=rc, signal=sig, stdout=so, stderr=se)
            except subprocess.TimeoutExpired:
                # TODO(安全缺口)：此处只终止了 wsl.exe，Linux 侧进程组清理待实现
                result.run = RunResult(timed_out=True)
            return result
        except Exception as e:
            result.compile = CompileResult(success=False, diagnostics=str(e))
            return result
        finally:
            if td:
                try:
                    subprocess.run(base + [f'rm -rf "{td}"'],
                                   capture_output=True, timeout=15)
                except Exception:
                    pass


class DockerBackend(ExecutionBackend):
    def backend_id(self) -> str:
        return "docker"
    def state(self) -> BackendState:
        return BackendState.NOT_INSTALLED
    def capabilities(self) -> frozenset[str]:
        return frozenset()
    def probe(self) -> bool:
        return False
    def execute(self, creq: CompileRequest, rreq: RunRequest) -> ExecutionResult:
        raise NotImplementedError("DockerBackend")


def discover_backends() -> list[ExecutionBackend]:
    candidates: list[ExecutionBackend] = []
    if platform.system() == "Linux":
        candidates.append(LinuxNativeBackend())
    elif platform.system() == "Windows":
        candidates.append(WindowsClangBackend())
        candidates.append(WSL2Backend())
        candidates.append(DockerBackend())
    return [b for b in candidates if b.state() == BackendState.AVAILABLE]


def select_backend(required_capabilities: set[str] | None = None) -> Optional[ExecutionBackend]:
    if required_capabilities is None:
        required_capabilities = set()
    for b in discover_backends():
        if required_capabilities.issubset(b.capabilities()):
            return b
    return None
